import Database from 'better-sqlite3';
import { ulid } from 'ulid';
import bcrypt from 'bcryptjs';

const db = new Database('omniverse.db');

db.pragma('journal_mode = WAL');

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    github_id TEXT,
    google_id TEXT,
    discord_id TEXT,
    avatar_url TEXT,
    github_username TEXT,
    provider TEXT DEFAULT 'local',
    phone_number TEXT,
    platform_balance REAL DEFAULT 0,
    seller_balance REAL DEFAULT 0,
    commission_rate REAL DEFAULT 0.25,
    is_banned BOOLEAN DEFAULT 0,
    is_verified BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS platform_settings (
    id TEXT PRIMARY KEY,
    key TEXT UNIQUE NOT NULL,
    value TEXT NOT NULL
  );
  
  INSERT OR IGNORE INTO platform_settings (id, key, value) VALUES ('1', 'global_commission_rate', '0.25');
  INSERT OR IGNORE INTO platform_settings (id, key, value) VALUES ('2', 'platform_wallet_balance', '0');

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    buyer_id TEXT,
    seller_id TEXT,
    listing_id TEXT,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'USD',
    platform_fee REAL NOT NULL,
    seller_earnings REAL NOT NULL,
    payment_method TEXT,
    status TEXT DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users (id),
    FOREIGN KEY (seller_id) REFERENCES users (id),
    FOREIGN KEY (listing_id) REFERENCES listings (id)
  );

  CREATE TABLE IF NOT EXISTS payout_methods (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    method_type TEXT NOT NULL,
    details TEXT NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS payout_requests (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    amount REAL NOT NULL,
    method_id TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    admin_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    processed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (method_id) REFERENCES payout_methods (id)
  );

  CREATE TABLE IF NOT EXISTS repositories (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    repo_name TEXT NOT NULL,
    repo_url TEXT NOT NULL,
    description TEXT,
    stars INTEGER DEFAULT 0,
    forks INTEGER DEFAULT 0,
    language TEXT,
    last_sync DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS listings (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price REAL NOT NULL,
    type TEXT NOT NULL,
    mode TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    seller_id TEXT,
    buyer_id TEXT,
    image_url TEXT,
    file_url TEXT,
    tags TEXT,
    sales INTEGER DEFAULT 0,
    rating REAL DEFAULT 0,
    is_approved BOOLEAN DEFAULT 1,
    is_featured BOOLEAN DEFAULT 0,
    discount_percentage REAL DEFAULT 0,
    discount_type TEXT DEFAULT 'None',
    custom_badge TEXT,
    screenshots TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users (id),
    FOREIGN KEY (buyer_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    listing_id TEXT NOT NULL,
    buyer_id TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (listing_id) REFERENCES listings (id),
    FOREIGN KEY (buyer_id) REFERENCES users (id)
  );
`);

// Seed data
const userCount = db.prepare("SELECT count(*) as count FROM users").get() as any;
if (userCount.count === 0) {
  const adminId = ulid();
  const proUI = ulid();
  const quantAI = ulid();
  const codeStack = ulid();
  const designX = ulid();
  const finVentures = ulid();
  const aiMasters = ulid();

  const hash = bcrypt.hashSync('password123', 10);
  const insertUser = db.prepare("INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)");
  
  insertUser.run(adminId, 'Admin', 'admin@omniverse.com', hash, 'admin');
  insertUser.run(proUI, 'ProUI', 'proui@omniverse.com', hash, 'user');
  insertUser.run(quantAI, 'QuantAI', 'quant@omniverse.com', hash, 'user');
  insertUser.run(codeStack, 'CodeStack', 'code@omniverse.com', hash, 'user');
  insertUser.run(designX, 'DesignX', 'design@omniverse.com', hash, 'user');
  insertUser.run(finVentures, 'FinVentures', 'fin@omniverse.com', hash, 'user');
  insertUser.run(aiMasters, 'AI Masters', 'aimasters@omniverse.com', hash, 'user');

  const insertListing = db.prepare("INSERT INTO listings (id, title, description, price, type, mode, seller_id, image_url, tags, sales, rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  
  insertListing.run('1', 'Apex - Premium SaaS Analytics Dashboard', 'A complete, production-ready full-stack SaaS analytics platform. Built with Next.js, Tailwind, and Prisma.', 249, 'Full Stack Project', 'Unlimited', proUI, 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', JSON.stringify(["Next.js", "SaaS", "Dashboard"]), 145, 4.9);
  
  insertListing.run('2', 'NeuralTrade - Crypto AI Bot Core', 'High-frequency trading algorithm with continuous learning. Includes backtesting engine and Binance API integration.', 5900, 'AI System', 'Exclusive', quantAI, 'https://images.unsplash.com/photo-1642104704074-907c0698cbd9?auto=format&fit=crop&w=800&q=80', JSON.stringify(["Python", "Machine Learning", "Trading"]), 0, 0);

  insertListing.run('3', 'EvoStore - E-commerce Multi-vendor Platform', 'Clone of major multi-vendor stores. Built with Node.js, React, and MongoDB. Includes admin and vendor dashboards.', 199, 'SaaS Platform', 'Unlimited', codeStack, 'https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&w=800&q=80', JSON.stringify(["React", "Node.js", "E-commerce"]), 890, 4.7);

  insertListing.run('4', 'Visionary - Mobile App UI Kit', '150+ premium mobile app screens for iOS and Android. Auto-layout, variants, and dark mode included.', 49, 'UI Kit', 'Unlimited', designX, 'https://images.unsplash.com/photo-1607252656733-fd74e47190f8?auto=format&fit=crop&w=800&q=80', JSON.stringify(["Figma", "UI", "Mobile"]), 3200, 4.9);

  insertListing.run('5', 'NeoBank - Complete FinTech App (Acquisition)', 'Fully functioning FinTech application with $15k MMR. 10k Active users. Selling full ownership including domains and codebase.', 120000, 'Digital Business', 'Exclusive', finVentures, 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=800&q=80', JSON.stringify(["FinTech", "Acquisition", "React Native"]), 0, 5.0);

  insertListing.run('6', 'PromptGenius - 10,000+ AI Prompts', 'The ultimate collection of prompts for Midjourney, ChatGPT, and Stable Diffusion.', 19, 'Prompt Pack', 'Unlimited', aiMasters, 'https://images.unsplash.com/photo-1684496269651-789304910b80?auto=format&fit=crop&w=800&q=80', JSON.stringify(["AI", "Prompts", "ChatGPT"]), 12500, 4.6);
}

export default db;
