import { useState, FormEvent, useEffect } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import { Search, ShoppingCart, User, Bell, Menu, Cpu, LogOut, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LoginDialog } from "@/components/LoginDialog";
import { useAuth } from "@/lib/auth";
import { useCurrency } from "@/lib/currency";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export default function Layout() {
  const { user, isAuthenticated, logout, authError, clearError } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchNotifications = async () => {
    if (!isAuthenticated) return;
    const token = localStorage.getItem("omniverse_token");
    try {
      const res = await fetch("/api/notifications", { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (res.ok) {
        setNotifications(data.notifications || []);
        setUnreadCount(data.unreadCount || 0);
      }
    } catch(e) { console.error(e) }
  };

  useEffect(() => {
    fetchNotifications();
    const inv = setInterval(fetchNotifications, 30000); // Check every 30s
    return () => clearInterval(inv);
  }, [isAuthenticated]);

  const markNotificationsRead = async () => {
    if (unreadCount === 0) return;
    const token = localStorage.getItem("omniverse_token");
    await fetch("/api/notifications/read", { method: "POST", headers: { Authorization: `Bearer ${token}` } });
    setUnreadCount(0);
    setNotifications(prev => prev.map(n => ({...n, is_read: 1})));
  };


  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-white/10 glass">
        {authError && (
          <div className="bg-red-500/90 text-white px-4 py-2 flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <span className="font-semibold">Authentication Error:</span>
              <span>{decodeURIComponent(authError)}</span>
            </div>
            <div className="flex items-center gap-2">
              <LoginDialog>
                <Button variant="outline" size="sm" className="h-7 text-xs bg-black/20 border-white/20 hover:bg-black/40">Try Again</Button>
              </LoginDialog>
              <Button variant="ghost" size="sm" onClick={clearError} className="h-7 w-7 p-0 rounded-full hover:bg-black/20">
                &times;
              </Button>
            </div>
          </div>
        )}
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
               <Cpu className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight hidden sm:inline-block">
              OMNIVERSE
            </span>
          </Link>

          <form onSubmit={handleSearch} className="flex-1 max-w-2xl hidden md:flex items-center relative">
            <Search className="absolute left-3 w-4 h-4 text-muted-foreground" />
            <Input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search apps, websites, AI models, source codes..." 
              className="w-full pl-9 bg-white/5 border-white/10 focus-visible:ring-indigo-500 rounded-full h-10 transition-all focus:bg-white/10"
            />
          </form>

          <nav className="flex items-center gap-1 sm:gap-2">
             <Button variant="ghost" size="icon" className="md:hidden">
               <Search className="w-5 h-5" />
             </Button>
             {isAuthenticated && (
               <Popover onOpenChange={(open) => { if(open) markNotificationsRead() }}>
                 <PopoverTrigger asChild>
                   <Button variant="ghost" size="icon" className="hidden sm:inline-flex relative">
                     <Bell className="w-5 h-5 text-muted-foreground hover:text-white" />
                     {unreadCount > 0 && (
                       <span className="absolute top-1 right-1 w-2 h-2 bg-pink-500 rounded-full animate-pulse" />
                     )}
                   </Button>
                 </PopoverTrigger>
                 <PopoverContent align="end" className="w-80 p-0 bg-black/90 backdrop-blur-xl border border-white/10 text-white">
                   <div className="p-4 border-b border-white/10 flex justify-between items-center">
                     <h4 className="font-semibold text-sm">Notifications</h4>
                     {unreadCount > 0 && <Badge className="bg-pink-500 text-white">{unreadCount} New</Badge>}
                   </div>
                   <ScrollArea className="h-72">
                     {notifications.length === 0 ? (
                       <div className="p-8 text-center text-muted-foreground text-sm">No notifications right now.</div>
                     ) : (
                       <div className="divide-y divide-white/5">
                         {notifications.map((n: any) => (
                           <div key={n.id} className={`p-4 flex gap-3 hover:bg-white/5 transition-colors ${!n.is_read ? 'bg-white/[0.02]' : ''}`}>
                             <div className="mt-1 w-2 h-2 rounded-full bg-indigo-500 flex-shrink-0" />
                             <div>
                               <p className="text-sm">{n.message}</p>
                               <span className="text-xs text-muted-foreground mt-1 block">{new Date(n.created_at).toLocaleString()}</span>
                             </div>
                           </div>
                         ))}
                       </div>
                     )}
                   </ScrollArea>
                 </PopoverContent>
               </Popover>
             )}
             
             <div className="hidden sm:flex ml-1 w-20">
               <Select value={currency} onValueChange={(val: any) => setCurrency(val)}>
                 <SelectTrigger className="bg-transparent border-none focus:ring-0 text-sm h-8">
                   <SelectValue />
                 </SelectTrigger>
                 <SelectContent>
                   <SelectItem value="USD">USD</SelectItem>
                   <SelectItem value="EUR">EUR</SelectItem>
                   <SelectItem value="GBP">GBP</SelectItem>
                   <SelectItem value="JPY">JPY</SelectItem>
                 </SelectContent>
               </Select>
             </div>

             <Button variant="ghost" size="icon">
               <ShoppingCart className="w-5 h-5 text-muted-foreground hover:text-white" />
             </Button>
             <div className="h-8 w-px bg-white/10 mx-1 sm:mx-2 hidden sm:block" />
             <Link to="/sell" className="hidden sm:inline-flex">
               <Button className="bg-white text-black hover:bg-gray-200 font-medium rounded-full">
                 Sell Asset
               </Button>
             </Link>
             
             {isAuthenticated ? (
               <div className="flex items-center gap-1 sm:gap-2 ml-1">
                 <Link to="/dashboard">
                   <Button variant="ghost" className="rounded-full border border-white/10 px-4 hidden sm:inline-flex">
                     {user?.name}
                   </Button>
                 </Link>
                 {user?.role === 'admin' && (
                   <Link to="/admin">
                     <Button variant="ghost" className="rounded-full bg-red-500/20 text-red-400 border border-red-500/50 px-4 hidden sm:inline-flex">
                       Admin
                     </Button>
                   </Link>
                 )}
                 <Button variant="ghost" size="icon" onClick={() => logout()} className="rounded-full border border-white/10 hidden sm:inline-flex">
                   <LogOut className="w-4 h-4" />
                 </Button>
               </div>
             ) : (
               <LoginDialog>
                 <Button variant="ghost" className="rounded-full border border-white/10 ml-1 px-4 hidden sm:inline-flex">
                   Sign In
                 </Button>
               </LoginDialog>
             )}
             
             <Button variant="ghost" size="icon" className="md:hidden">
               <Menu className="w-5 h-5" />
             </Button>
          </nav>
        </div>
        {/* Categories Bar */}
        <div className="border-t border-white/5 bg-black/40 overflow-x-auto no-scrollbar">
           <div className="container mx-auto px-4 h-10 flex items-center gap-6 text-sm font-medium text-muted-foreground whitespace-nowrap">
             <Link to="/?q=App" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">Mobile Apps</Link>
             <Link to="/?q=AI" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">AI Systems</Link>
             <Link to="/?q=Website" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">Full Websites</Link>
             <Link to="/?q=SaaS" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">SaaS Platforms</Link>
             <Link to="/?q=Source Code" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">Source Code</Link>
             <Link to="/?q=UI Kit" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">UI/UX Kits</Link>
             <Link to="/?q=Plugin" className="hover:text-white transition-colors py-2 border-b-2 border-transparent hover:border-white">Plugins</Link>
           </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-black py-12 text-muted-foreground mt-24">
         <div className="container mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                 <div className="w-6 h-6 rounded-md bg-white flex items-center justify-center">
                   <Cpu className="w-4 h-4 text-black" />
                 </div>
                 <span className="font-display font-bold text-white">OMNIVERSE</span>
              </div>
              <p className="text-sm">The world's premium marketplace for digital assets, businesses, and AI.</p>
            </div>
            <div>
               <h4 className="font-medium text-white mb-4">Buy</h4>
               <ul className="space-y-2 text-sm">
                 <li><Link to="/" className="hover:text-white transition-colors">Digital Products</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">Exclusive Assets</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">AI Models</Link></li>
               </ul>
            </div>
            <div>
               <h4 className="font-medium text-white mb-4">Sell</h4>
               <ul className="space-y-2 text-sm">
                 <li><Link to="/" className="hover:text-white transition-colors">Start Selling</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">Developer API</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">Seller Guide</Link></li>
               </ul>
            </div>
            <div>
               <h4 className="font-medium text-white mb-4">Platform</h4>
               <ul className="space-y-2 text-sm">
                 <li><Link to="/" className="hover:text-white transition-colors">About Us</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">Terms of Service</Link></li>
                 <li><Link to="/" className="hover:text-white transition-colors">Privacy Policy</Link></li>
               </ul>
            </div>
         </div>
      </footer>
    </div>
  );
}
