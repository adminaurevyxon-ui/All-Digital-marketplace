import { useState, ReactNode, FormEvent } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Cpu, Github, Mail, Smartphone, Facebook, Twitter, Lock, CheckCircle2 } from "lucide-react"
import { useAuth } from "@/lib/auth"

export function LoginDialog({ children }: { children: ReactNode }) {
  const { login } = useAuth();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  
  // View states: 'options' | 'email-pass' | 'otp-send' | 'otp-verify'
  const [view, setView] = useState<'options' | 'email-pass' | 'otp-send' | 'otp-verify'>('options');
  const [isRegister, setIsRegister] = useState(false);
  
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");

  const handleOAuth = async (provider: string) => {
    try {
      const res = await fetch(`/api/auth/${provider}`);
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setError(data.error || "OAuth failed");
      }
    } catch (err) {
      setError(`Network error connecting to ${provider} auth. Please try again.`);
    }
  };

  const handleEmailPass = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const endpoint = isRegister ? "/api/auth/register" : "/api/auth/login";
      const payload = isRegister ? { name, email, password } : { email, password };
      
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Authentication failed");
      
      login(data.token, data.user);
      setOpen(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSendOTP = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP");
      setView('otp-verify');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code: otpCode }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Invalid OTP");
      
      login(data.token, data.user);
      setOpen(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={children} />
      <DialogContent className="sm:max-w-[425px] bg-black/90 backdrop-blur-xl border border-white/10 text-white p-0 overflow-hidden">
        <div className="p-6">
          <DialogHeader>
            <div className="mx-auto w-12 h-12 bg-white/5 rounded-xl border border-white/10 flex items-center justify-center mb-4">
               {view === 'otp-verify' ? <Lock className="text-green-400" /> : <Cpu className="w-6 h-6 text-indigo-400" />}
            </div>
            <DialogTitle className="text-center font-display text-2xl">
              {view === 'options' ? "Join Omniverse" : 
               view === 'email-pass' ? (isRegister ? "Create Account" : "Access Account") :
               view === 'otp-send' ? "Passwordless Login" : "Verify Code"}
            </DialogTitle>
            <DialogDescription className="text-center text-muted-foreground">
              {view === 'options' ? "Choose your preferred authentication method." : 
               view === 'otp-verify' ? `Enter the 6-digit code sent to ${email}` : "Secure your enterprise identity."}
            </DialogDescription>
          </DialogHeader>

          <div className="mt-6">
            {error && <div className="mb-4 text-red-400 text-sm text-center bg-red-400/10 p-3 rounded-lg border border-red-400/20">{error}</div>}
            
            {view === 'options' && (
              <div className="space-y-3">
                <Button onClick={() => handleOAuth('github')} variant="outline" className="w-full h-12 border-white/10 hover:bg-white/5 justify-start px-4">
                  <Github className="w-5 h-5 mr-3" /> Continue with GitHub
                </Button>
                <Button onClick={() => handleOAuth('google')} variant="outline" className="w-full h-12 border-white/10 hover:bg-white/5 justify-start px-4">
                  <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" /><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" /><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" /><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" /></svg>
                  Continue with Google
                </Button>
                
                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-white/10" /></div>
                  <div className="relative flex justify-center text-xs uppercase"><span className="bg-black/90 px-2 text-muted-foreground">Or</span></div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button onClick={() => setView('otp-send')} variant="outline" className="h-12 border-white/10 hover:bg-white/5">
                    <Smartphone className="w-4 h-4 mr-2" /> Phone / OTP
                  </Button>
                  <Button onClick={() => setView('email-pass')} variant="outline" className="h-12 border-white/10 hover:bg-white/5">
                    <Mail className="w-4 h-4 mr-2" /> Email
                  </Button>
                </div>
              </div>
            )}

            {view === 'email-pass' && (
              <form onSubmit={handleEmailPass} className="space-y-4">
                {isRegister && (
                  <Input placeholder="Your Name" value={name} onChange={(e) => setName(e.target.value)} className="bg-white/5 border-white/10 h-12" required />
                )}
                <Input type="email" placeholder="name@company.com" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-white/5 border-white/10 h-12" required />
                <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-white/5 border-white/10 h-12" required />
                <Button type="submit" disabled={loading} className="w-full h-12 bg-white text-black hover:bg-gray-200">
                  {loading ? "Processing..." : (isRegister ? "Create Account" : "Sign In")}
                </Button>
                <div className="text-center mt-2 text-sm">
                  <button type="button" onClick={() => setIsRegister(!isRegister)} className="text-muted-foreground hover:text-white transition-colors">
                    {isRegister ? "Already have an account? Sign In" : "Don't have an account? Register"}
                  </button>
                </div>
                <Button type="button" variant="ghost" onClick={() => setView('options')} className="w-full mt-2 text-xs opacity-60">Back to Options</Button>
              </form>
            )}

            {view === 'otp-send' && (
              <form onSubmit={handleSendOTP} className="space-y-4">
                <Input type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-white/5 border-white/10 h-12" required />
                <Button type="submit" disabled={loading} className="w-full h-12 bg-white text-black hover:bg-gray-200">
                  {loading ? "Sending..." : "Send Magic Code"}
                </Button>
                <Button type="button" variant="ghost" onClick={() => setView('options')} className="w-full mt-2 text-xs opacity-60">Back to Options</Button>
              </form>
            )}

            {view === 'otp-verify' && (
              <form onSubmit={handleVerifyOTP} className="space-y-4">
                <Input 
                  type="text" 
                  placeholder="000000" 
                  value={otpCode} 
                  onChange={(e) => setOtpCode(e.target.value)} 
                  className="bg-white/5 border-white/10 h-12 text-center text-2xl tracking-widest font-mono" 
                  maxLength={6}
                  required 
                />
                <Button type="submit" disabled={loading} className="w-full h-12 bg-indigo-500 hover:bg-indigo-400 text-white font-bold">
                  {loading ? "Verifying..." : "Verify & Login"}
                </Button>
                <Button type="button" variant="ghost" onClick={() => setView('otp-send')} className="w-full mt-2 text-xs opacity-60">Resend Code</Button>
              </form>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
