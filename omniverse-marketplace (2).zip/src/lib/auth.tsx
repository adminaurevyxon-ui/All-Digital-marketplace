import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type User = { id: string; name: string; email: string; role?: string };

interface AuthContextType {
  user: User | null;
  token: string | null;
  authError: string | null;
  login: (token: string, user: User) => void;
  logout: () => void;
  clearError: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  authError: null,
  login: () => {},
  logout: () => {},
  clearError: () => {},
  isAuthenticated: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Parse URL for OAuth tokens or errors
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");
    const urlError = params.get("error");
    
    if (urlError) {
      console.error("Auth error from URL:", urlError);
      setAuthError(urlError);
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    if (urlToken) {
      localStorage.setItem("omniverse_token", urlToken);
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    const savedToken = localStorage.getItem("omniverse_token");
    if (savedToken) {
      fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${savedToken}` },
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.user) {
            setUser(data.user);
            setToken(savedToken);
          } else {
            localStorage.removeItem("omniverse_token");
          }
        })
        .catch(() => {
          localStorage.removeItem("omniverse_token");
        })
        .finally(() => {
          setIsLoaded(true);
        });
    } else {
      setIsLoaded(true);
    }
  }, []);

  const login = (newToken: string, newUser: User) => {
    localStorage.setItem("omniverse_token", newToken);
    setToken(newToken);
    setUser(newUser);
    setAuthError(null);
  };

  const logout = () => {
    localStorage.removeItem("omniverse_token");
    setToken(null);
    setUser(null);
  };

  const clearError = () => setAuthError(null);

  if (!isLoaded) {
    return <div className="min-h-screen bg-black flex items-center justify-center text-white">Loading Omniverse...</div>;
  }

  return (
    <AuthContext.Provider value={{ user, token, authError, login, logout, clearError, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
