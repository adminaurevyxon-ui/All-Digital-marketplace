/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Listing from "./pages/Listing";
import Sell from "./pages/Sell";
import Dashboard from "./pages/Dashboard";
import Admin from "./pages/Admin";
import ManageListing from "./pages/ManageListing";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="listing/:id" element={<Listing />} />
        <Route path="manage/:id" element={<ManageListing />} />
        <Route path="sell" element={<Sell />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="admin" element={<Admin />} />
      </Route>
    </Routes>
  );
}
