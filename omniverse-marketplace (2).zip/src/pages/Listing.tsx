import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowLeft, Star, Shield, Lock, Download, CheckCircle2, TrendingUp, Users, Cpu, FileJson, Check, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/lib/auth";
import { LoginDialog } from "@/components/LoginDialog";

export default function Listing() {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const [listing, setListing] = useState<any>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState(false);
  const [error, setError] = useState("");

  const fetchListing = () => {
    fetch(`/api/listings/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error("Item not found");
        return res.json();
      })
      .then((data) => setListing(data.listing))
      .catch((err) => setError("Failed to fetch listing"));
  };

  useEffect(() => {
    fetchListing();
  }, [id]);

  const handlePurchase = async () => {
    if (!isAuthenticated) return;
    setPurchasing(true);
    setError("");
    
    try {
      const token = localStorage.getItem("omniverse_token");
      const res = await fetch(`/api/buy/${listing.id}`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to complete transaction.");
      
      if (data.url) {
        window.location.href = data.url;
      } else {
        setPurchaseSuccess(true);
        fetchListing(); // Refresh listing to show 'sold' status or updated sales
      }
    } catch(err: any) {
      setError(err.message);
    } finally {
      setPurchasing(false);
    }
  };

  const handleDownload = () => {
    const token = localStorage.getItem("omniverse_token");
    window.open(`/api/downloads/${listing.id}?token=${token}`, "_blank");
  };

  if (error) {
    return <div className="h-screen flex items-center justify-center text-red-500">{error}</div>;
  }

  if (!listing) {
    return <div className="h-screen flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full" /></div>;
  }

  const isExclusive = listing.mode === "Exclusive";
  const isSoldOut = isExclusive && listing.status === 'sold';
  const isSeller = listing.seller_id === user?.id;
  const isBuyer = listing.buyer_id === user?.id;
  const hasAccess = isSeller || isBuyer;
  const discountPct = listing.discount_percentage || 0;
  const originalPrice = listing.price || 0;
  const discountedPrice = originalPrice - (originalPrice * (discountPct / 100));

  return (
    <div className="pb-20">
      {/* Header bar */}
      <div className="border-b border-white/5 bg-black/80 backdrop-blur-md sticky top-16 z-40">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
           <Link to="/" className="text-muted-foreground hover:text-white flex items-center text-sm font-medium">
             <ArrowLeft className="w-4 h-4 mr-2" /> Back to Market
           </Link>
           <div className="flex items-center gap-4">
              <div className="flex flex-col items-end">
                {discountPct > 0 ? (
                  <>
                     <span className="text-xs text-muted-foreground line-through">${originalPrice.toLocaleString()}</span>
                     <span className="font-display font-bold text-lg text-emerald-400">${discountedPrice.toLocaleString()}</span>
                  </>
                ) : (
                  <span className="font-display font-bold text-lg">${originalPrice.toLocaleString()}</span>
                )}
              </div>
              {isSeller ? (
                <Link to={`/manage/${listing.id}`}>
                  <Button size="sm" className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-[0_0_15px_rgba(79,70,229,0.5)]">
                     Manage System
                  </Button>
                </Link>
              ) : isSoldOut ? (
                <Badge variant="outline" className="text-red-500 border-red-500 bg-red-500/10 h-8">SOLD OUT</Badge>
              ) : isAuthenticated ? (
                <Button size="sm" onClick={handlePurchase} disabled={purchasing} className={isExclusive ? "bg-amber-500 hover:bg-amber-400 text-black font-semibold" : "bg-indigo-500 hover:bg-indigo-600 font-semibold"}>
                   {purchasing ? "Processing..." : (isExclusive ? "Acquire Now" : "Purchase License")}
                </Button>
              ) : (
                <LoginDialog>
                  <Button size="sm" className={isExclusive ? "bg-amber-500 hover:bg-amber-400 text-black font-semibold" : "bg-indigo-500 hover:bg-indigo-600 font-semibold"}>
                     Sign in to Buy
                  </Button>
                </LoginDialog>
              )}
           </div>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {purchaseSuccess && (
              <div className="bg-green-500/10 border border-green-500/30 text-green-400 p-6 rounded-2xl flex items-center gap-4">
                <CheckCircle2 className="w-8 h-8 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-lg">Transaction Successful!</h3>
                  <p className="text-sm opacity-80">You have successfully acquired {listing.title}.</p>
                </div>
              </div>
            )}
            
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
               <div className="flex gap-2 mb-4 flex-wrap">
                 {isSoldOut ? (
                   <Badge className="bg-red-500 text-white hover:bg-red-600">UNAVAILABLE: ACQUIRED</Badge>
                 ) : isExclusive ? (
                   <Badge className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border border-amber-500/20">EXCLUSIVE ACQUISITION</Badge>
                 ) : (
                   <Badge variant="secondary" className="bg-white/5 border-white/10">UNLIMITED LICENSE</Badge>
                 )}
                 <Badge variant="secondary" className="bg-white/5 border-white/10">{listing.type}</Badge>
                 {listing.custom_badge && (
                   <Badge className="bg-pink-500 text-white border-none">{listing.custom_badge}</Badge>
                 )}
                 {discountPct > 0 && listing.discount_type === "Limited Time" && (
                   <Badge className="bg-red-500 text-white border-none animate-pulse">{discountPct}% OFF (Limited Time)</Badge>
                 )}
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-4">{listing.title}</h1>
              <p className="text-xl text-muted-foreground mb-6">{listing.description}</p>
              
              <div className="flex flex-wrap items-center gap-6 text-sm">
                 <div className="flex items-center gap-2">
                   <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold border border-indigo-500/30">
                     {listing.author?.[0] || "U"}
                   </div>
                   <div>
                     <p className="text-muted-foreground text-xs">Creator</p>
                     <p className="font-medium text-white flex items-center gap-1">
                       {listing.author || "Unknown"}
                       {listing.is_verified ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : null}
                     </p>
                   </div>
                 </div>
                 {!isExclusive && (
                    <>
                      <div className="w-px h-8 bg-white/10" />
                      <div className="flex items-center gap-2">
                         <div className="flex text-yellow-500">
                           <Star className="w-4 h-4 fill-yellow-500" />
                           <Star className="w-4 h-4 fill-yellow-500" />
                           <Star className="w-4 h-4 fill-yellow-500" />
                           <Star className="w-4 h-4 fill-yellow-500" />
                           <Star className="w-4 h-4 fill-yellow-500" />
                         </div>
                         <span className="font-medium">{listing.rating || "5.0"}</span>
                      </div>
                      <div className="w-px h-8 bg-white/10" />
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Download className="w-4 h-4" /> {listing.sales || 0} Sales
                      </div>
                    </>
                 )}
                 {isSoldOut && (
                    <>
                      <div className="w-px h-8 bg-white/10" />
                      <div className="flex items-center gap-2 text-red-400">
                        <Lock className="w-4 h-4" /> Permanently Transferred
                      </div>
                    </>
                 )}
              </div>
            </motion.div>

            {/* Media Gallery */}
            <motion.div 
               initial={{ opacity: 0, scale: 0.98 }} 
               animate={{ opacity: 1, scale: 1 }}
               transition={{ delay: 0.1 }}
            >
               {listing.screenshots && listing.screenshots.length > 0 ? (
                 <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory pb-4 hide-scrollbar">
                    {listing.screenshots.map((src: string, i: number) => (
                       <div key={i} className="aspect-video shrink-0 w-full md:w-[80%] snap-center rounded-2xl overflow-hidden glass border border-white/10 relative">
                         <img src={src} alt={`${listing.title} screenshot ${i+1}`} className="w-full h-full object-cover" />
                       </div>
                    ))}
                 </div>
               ) : (
                 <div className="rounded-2xl overflow-hidden border border-white/10 glass relative aspect-video hidden md:block">
                   <img src={listing.image_url || listing.image} alt={listing.title} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                 </div>
               )}
            </motion.div>

            {/* Content Tabs */}
            <Tabs defaultValue="overview" className="mt-12">
              <TabsList className="bg-white/5 border border-white/10 p-1 rounded-xl mb-6">
                <TabsTrigger value="overview" className="rounded-lg data-[state=active]:bg-white/10 data-[state=active]:text-white">Overview</TabsTrigger>
                <TabsTrigger value="features" className="rounded-lg data-[state=active]:bg-white/10 data-[state=active]:text-white">Features & Tech</TabsTrigger>
                {isExclusive && <TabsTrigger value="analytics" className="rounded-lg data-[state=active]:bg-white/10 data-[state=active]:text-white">Business Analytics</TabsTrigger>}
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6 text-muted-foreground leading-relaxed">
                 <h3 className="text-2xl font-display font-semibold text-white mb-4">About this Product</h3>
                 <p>This premium digital asset is built using the latest modern technologies and follows best practices for scalable architecture and high-performance user interfaces.</p>
                 <p>Whether you are looking to bootstrap a new startup, upgrade existing infrastructure, or acquire a cash-flowing business, this product delivers exceptional value.</p>
                 
                 <div className="grid grid-cols-2 gap-4 mt-8">
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                       <Cpu className="w-6 h-6 text-indigo-400 mb-3" />
                       <h4 className="font-medium text-white mb-1">Production Ready</h4>
                       <p className="text-sm">Optimized for immediate deployment to cloud providers.</p>
                    </div>
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                       <FileJson className="w-6 h-6 text-pink-400 mb-3" />
                       <h4 className="font-medium text-white mb-1">Clean Architecture</h4>
                       <p className="text-sm">Highly modular and maintainable codebase structure.</p>
                    </div>
                 </div>
              </TabsContent>

              <TabsContent value="features" className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-4 gap-x-8">
                  {listing.tags?.length > 0 ? listing.tags.map((tag: string, i: number) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                      <span className="text-white">{tag}</span>
                    </div>
                  )) : (
                    ['React Component', 'Tailwind Supported', 'Clean Code'].map((feature, i) => (
                      <div key={i} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                        <span className="text-white">{feature}</span>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              {isExclusive && (
                <TabsContent value="analytics" className="space-y-6">
                   <div className="grid grid-cols-3 gap-4">
                      <div className="p-5 rounded-2xl bg-white/5 border border-white/10 text-center">
                        <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                        <p className="text-3xl font-display font-bold text-white">$15.2k</p>
                        <p className="text-sm text-muted-foreground">Monthly Rev</p>
                      </div>
                      <div className="p-5 rounded-2xl bg-white/5 border border-white/10 text-center">
                        <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                        <p className="text-3xl font-display font-bold text-white">45k</p>
                        <p className="text-sm text-muted-foreground">Active Users</p>
                      </div>
                      <div className="p-5 rounded-2xl bg-white/5 border border-white/10 text-center">
                        <Shield className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                        <p className="text-3xl font-display font-bold text-white">92%</p>
                        <p className="text-sm text-muted-foreground">Retention Rate</p>
                      </div>
                   </div>
                   <div className="aspect-[21/9] rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center relative overflow-hidden mt-6">
                      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-indigo-500/20 to-transparent" />
                      <p className="text-muted-foreground z-10 flex items-center gap-2"><Lock className="w-4 h-4" /> Comprehensive Analytics available upon NDA signing.</p>
                   </div>
                </TabsContent>
              )}
            </Tabs>
          </div>

          {/* Sticky Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-32 space-y-6">
              <div className="rounded-2xl border border-white/10 glass-card p-6">
                 {isSoldOut ? (
                   <div className="text-center py-6">
                     <Lock className="w-12 h-12 text-red-500 mx-auto mb-4" />
                     <h3 className="text-xl font-bold text-white mb-2">Acquired</h3>
                     <p className="text-muted-foreground mb-6">This asset has been permanently fully-transferred to its new owner.</p>
                     {hasAccess && listing.file_url ? (
                        <div onClick={handleDownload} className="cursor-pointer">
                          <Button className="w-full bg-indigo-500 hover:bg-indigo-400 text-white font-bold h-12">
                            <Download className="w-4 h-4 mr-2" /> Download Assets
                          </Button>
                        </div>
                     ) : null}
                     {isSeller && (
                       <Link to={`/manage/${listing.id}`}>
                         <Button className="w-full mt-3 bg-white/10 hover:bg-white/20 text-white font-bold h-12">
                           Manage System
                         </Button>
                       </Link>
                     )}
                   </div>
                 ) : isExclusive ? (
                   <>
                     <div className="flex items-center gap-3 mb-6">
                       <span className="bg-amber-500/20 text-amber-400 p-2.5 rounded-xl"><Lock className="w-7 h-7" /></span>
                       <div>
                         <h3 className="font-display font-bold text-xl text-white">Exclusive Rights</h3>
                         <p className="text-sm text-amber-400 font-medium">1 of 1 Available</p>
                       </div>
                     </div>
                     <div className="flex items-end gap-3 mb-6">
                       {discountPct > 0 ? (
                         <>
                           <div className="text-4xl font-display font-bold text-emerald-400">${discountedPrice.toLocaleString()}</div>
                           <div className="text-xl text-muted-foreground line-through mb-1">${originalPrice.toLocaleString()}</div>
                         </>
                       ) : (
                         <div className="text-4xl font-display font-bold">${originalPrice.toLocaleString()}</div>
                       )}
                     </div>
                     
                     {isSeller ? (
                       <Link to={`/manage/${listing.id}`}>
                         <Button size="lg" className="w-full mb-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold h-14 text-lg">
                           Manage System
                         </Button>
                       </Link>
                     ) : isBuyer ? (
                       <Button size="lg" onClick={handleDownload} className="w-full mb-4 bg-emerald-500 hover:bg-emerald-400 text-white font-bold h-14 text-lg">
                         <Download className="w-5 h-5 mr-2" /> Download Source
                       </Button>
                     ) : isAuthenticated ? (
                       <Button size="lg" onClick={handlePurchase} disabled={purchasing} className="w-full mb-4 bg-amber-500 hover:bg-amber-400 text-black font-bold h-14 text-lg">
                         {purchasing ? "Processing..." : "Acquire Full Ownership"}
                       </Button>
                     ) : (
                       <LoginDialog>
                         <Button size="lg" className="w-full mb-4 bg-amber-500 hover:bg-amber-400 text-black font-bold h-14 text-lg">
                           Sign In To Acquire
                         </Button>
                       </LoginDialog>
                     )}
                     
                     {!isSeller && !isBuyer && (
                       <Button variant="outline" className="w-full bg-white/5 border-white/10 h-12">
                         Contact Seller via Escrow
                       </Button>
                     )}

                     <Separator className="my-6 bg-white/10" />

                     <ul className="space-y-3 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-amber-500 mt-0.5" /> Sole ownership transfer</li>
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-amber-500 mt-0.5" /> Source code & IP rights</li>
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-amber-500 mt-0.5" /> Tech stack migration support</li>
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-amber-500 mt-0.5" /> Blockchain certificate minted</li>
                     </ul>
                   </>
                 ) : (
                   <>
                     <div className="mb-6">
                         <div className="flex items-end gap-3 mb-2">
                           {discountPct > 0 ? (
                             <>
                               <h3 className="font-display font-bold text-3xl text-emerald-400">${discountedPrice.toLocaleString()}</h3>
                               <h3 className="font-display font-medium text-lg text-muted-foreground line-through mb-1">${originalPrice.toLocaleString()}</h3>
                             </>
                           ) : (
                             <h3 className="font-display font-bold text-2xl text-white">${originalPrice.toLocaleString()}</h3>
                           )}
                         </div>
                         <Badge variant="outline" className="text-indigo-400 border-indigo-400/30 bg-indigo-400/10">Standard License</Badge>
                     </div>

                     {isSeller ? (
                       <Link to={`/manage/${listing.id}`}>
                          <Button size="lg" className="w-full mb-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold h-14 text-lg shadow-[0_0_20px_rgba(79,70,229,0.4)]">
                            Manage System
                          </Button>
                       </Link>
                     ) : isBuyer ? (
                       <Button size="lg" onClick={handleDownload} className="w-full mb-4 bg-emerald-500 hover:bg-emerald-400 text-white font-bold h-14 text-lg">
                         <Download className="w-5 h-5 mr-2" /> Download Source
                       </Button>
                     ) : isAuthenticated ? (
                       <Button size="lg" onClick={handlePurchase} disabled={purchasing} className="w-full mb-4 bg-indigo-500 hover:bg-indigo-600 text-white font-bold h-14 text-lg">
                         {purchasing ? "Processing..." : "Purchase & Download"}
                       </Button>
                     ) : (
                       <LoginDialog>
                         <Button size="lg" className="w-full mb-4 bg-indigo-500 hover:bg-indigo-600 text-white font-bold h-14 text-lg">
                           Sign In To Purchase
                         </Button>
                       </LoginDialog>
                     )}

                     {hasAccess && listing.file_url ? (
                        <div onClick={handleDownload} className="block mb-4 cursor-pointer">
                          <Button variant="outline" className="w-full border-green-500/50 bg-green-500/10 text-green-400 hover:bg-green-500/20 h-12">
                            <Download className="w-4 h-4 mr-2" /> Download File (Owned)
                          </Button>
                        </div>
                     ) : null}
                     
                     <Separator className="my-6 bg-white/10" />

                     <ul className="space-y-3 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-indigo-400 mt-0.5" /> Use for unlimited projects</li>
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-indigo-400 mt-0.5" /> Direct support from creator</li>
                        <li className="flex items-start gap-2"><Check className="w-4 h-4 text-indigo-400 mt-0.5" /> Lifetime free updates</li>
                     </ul>
                   </>
                 )}
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/5 p-5 flex items-center gap-4">
                 <Shield className="w-10 h-10 text-green-400 p-2 bg-green-400/10 rounded-full" />
                 <div>
                    <h4 className="font-medium text-white">Payment Protected</h4>
                    <p className="text-xs text-muted-foreground">Transactions are secured by enterprise encryption.</p>
                 </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
