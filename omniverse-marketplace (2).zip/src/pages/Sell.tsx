import React, { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/auth";
import { Lock, UploadCloud, Link as LinkIcon, DollarSign, Tag, CheckCircle2 } from "lucide-react";

export default function Sell() {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    type: "Mobile App",
    mode: "Unlimited",
    tags: "",
    discount_percentage: "0",
    discount_type: "None",
    custom_badge: "",
  });

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [assetFile, setAssetFile] = useState<File | null>(null);
  const [screenshots, setScreenshots] = useState<File[]>([]);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleScreenshotsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArr = Array.from(e.target.files);
      if (filesArr.length !== 8) {
         setError("You must upload exactly 8 screenshots.");
         return;
      }
      setError("");
      setScreenshots(filesArr);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      setError("You must be logged in to sell items.");
      return;
    }
    if (screenshots.length !== 8) {
      setError("You must upload exactly 8 screenshots before publishing.");
      return;
    }
    
    setLoading(true);
    setError("");

    try {
      const data = new FormData();
      data.append("title", formData.title);
      data.append("description", formData.description);
      data.append("price", formData.price);
      data.append("type", formData.type);
      data.append("mode", formData.mode);
      data.append("tags", formData.tags);
      data.append("discount_percentage", formData.discount_percentage);
      data.append("discount_type", formData.discount_type);
      data.append("custom_badge", formData.custom_badge);

      if (imageFile) data.append("image", imageFile);
      if (assetFile) data.append("asset", assetFile);
      screenshots.forEach(file => data.append("screenshots", file));

      const token = localStorage.getItem("omniverse_token");
      const res = await fetch("/api/listings", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: data,
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to upload asset");

      setSuccess(true);
      setTimeout(() => navigate(`/listing/${json.listingId}`), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6">
          <CheckCircle2 className="w-10 h-10 text-green-400" />
        </div>
        <h1 className="text-4xl font-display font-bold mb-4">Upload Successful!</h1>
        <p className="text-muted-foreground text-lg mb-8">Your digital asset is now live on Omniverse.</p>
        <p className="text-sm text-gray-500">Redirecting to your listing...</p>
      </div>
    );
  }

  const originalPrice = Number(formData.price) || 0;
  const discountPct = Number(formData.discount_percentage) || 0;
  const discountedPrice = originalPrice - (originalPrice * (discountPct / 100));

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl font-display font-bold mb-2">Sell an Asset</h1>
        <p className="text-muted-foreground mb-8">Upload your digital product, codebase, or AI model to the marketplace.</p>

        {!isAuthenticated && (
          <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200 p-4 rounded-xl mb-8 flex items-center gap-3">
            <Lock className="w-5 h-5 flex-shrink-0" />
            <p>You must sign in to upload assets. Please use the SignIn button in the header.</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6 glass-card p-6 md:p-8 rounded-2xl border border-white/5">
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-200 p-4 rounded-xl">
                {error}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Asset Title</label>
                <Input 
                  required 
                  placeholder="e.g. Apex SaaS Dashboard" 
                  className="bg-white/5 border-white/10"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
                <Textarea 
                  required 
                  placeholder="Describe your asset in detail..." 
                  className="bg-white/5 border-white/10 min-h-[120px]"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Custom Badge/Description Text</label>
                <Input 
                  placeholder="e.g. Limited Edition, Premium Version..." 
                  className="bg-white/5 border-white/10"
                  value={formData.custom_badge}
                  onChange={(e) => setFormData({ ...formData, custom_badge: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Price (USD)</label>
                  <div className="relative">
                    <DollarSign className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <Input 
                      type="number" 
                      required 
                      min="0"
                      step="1"
                      placeholder="249" 
                      className="bg-white/5 border-white/10 pl-9"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Tags (comma separated)</label>
                  <div className="relative">
                    <Tag className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <Input 
                      placeholder="React, Next.js, Android" 
                      className="bg-white/5 border-white/10 pl-9"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    />
                  </div>
                </div>
              </div>
              
              {/* Discount Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white/[0.02] p-4 rounded-xl border border-white/5">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Discount Percentage (%)</label>
                  <Input 
                    type="number" 
                    min="0"
                    max="100"
                    placeholder="0" 
                    className="bg-white/5 border-white/10"
                    value={formData.discount_percentage}
                    onChange={(e) => setFormData({ ...formData, discount_percentage: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Discount Type</label>
                  <select 
                    className="w-full bg-black/50 border border-white/10 rounded-md h-10 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 text-white"
                    value={formData.discount_type}
                    onChange={(e) => setFormData({ ...formData, discount_type: e.target.value })}
                  >
                    <option value="None" className="bg-gray-900">None</option>
                    <option value="Limited Time" className="bg-gray-900">Limited Time</option>
                    <option value="Unlimited" className="bg-gray-900">Unlimited Duration</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Asset Category</label>
                  <select 
                    className="w-full bg-black/50 border border-white/10 rounded-md h-10 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 text-white"
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  >
                    <option className="bg-gray-900">Mobile App</option>
                    <option className="bg-gray-900">Website</option>
                    <option className="bg-gray-900">SaaS Platform</option>
                    <option className="bg-gray-900">Source Code</option>
                    <option className="bg-gray-900">UI Kit</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Sale Mode</label>
                  <select 
                    className="w-full bg-black/50 border border-white/10 rounded-md h-10 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 text-white"
                    value={formData.mode}
                    onChange={(e) => setFormData({ ...formData, mode: e.target.value })}
                  >
                    <option className="bg-gray-900">Unlimited</option>
                    <option className="bg-gray-900">Exclusive</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-white/10">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Cover Image (Required)</label>
                <div className="border-2 border-dashed border-white/10 rounded-xl p-6 text-center hover:bg-white/[0.02] transition-colors cursor-pointer relative overflow-hidden">
                  <input 
                    type="file" 
                    accept="image/*" 
                    required
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" 
                    onChange={handleImageChange}
                  />
                  {imagePreview ? (
                    <img src={imagePreview} className="absolute inset-0 w-full h-full object-cover opacity-30" alt="" />
                  ) : null}
                  <div className="relative z-20 pointer-events-none">
                    <UploadCloud className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-gray-300">{imageFile ? imageFile.name : "Click or drag to upload cover image"}</p>
                    <p className="text-xs text-gray-500 mt-1">JPG, PNG up to 5MB</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Screenshots (Exactly 8 Required)</label>
                 <div className="border-2 border-dashed border-white/10 rounded-xl p-6 text-center hover:bg-white/[0.02] transition-colors cursor-pointer relative">
                    <input 
                      type="file" 
                      accept="image/png, image/jpeg" 
                      multiple
                      required
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" 
                      onChange={handleScreenshotsChange}
                    />
                    <UploadCloud className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-gray-300">{screenshots.length > 0 ? `${screenshots.length} / 8 uploaded` : "Click or drag exactly 8 screenshots"}</p>
                 </div>
                 {screenshots.length > 0 && screenshots.length !== 8 && (
                   <p className="text-red-400 text-xs mt-1">You currently have {screenshots.length} selected. You must have exactly 8.</p>
                 )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Digital Asset File (ZIP/APK)</label>
                <div className="border-2 border-dashed border-white/10 rounded-xl p-6 text-center hover:bg-white/[0.02] transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    accept=".zip,.rar,.tar,.gz,.apk"
                    required
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" 
                    onChange={(e) => setAssetFile(e.target.files?.[0] || null)}
                  />
                  <LinkIcon className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                  <p className="text-sm font-medium text-indigo-300">{assetFile ? assetFile.name : "Click or drag to upload source file (.zip, .apk)"}</p>
                  <p className="text-xs text-gray-500 mt-1">This file will be securely delivered to buyers.</p>
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              size="lg" 
              disabled={loading || !isAuthenticated} 
              className="w-full h-14 text-base font-semibold bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {loading ? "Uploading to Omniverse..." : "Publish Asset"}
            </Button>
          </form>

          {/* Real-time Preview */}
          <div>
            <div className="sticky top-24">
              <h3 className="font-display text-xl font-semibold mb-4 text-white">Live Preview</h3>
              <div className="glass-card rounded-2xl border border-white/5 overflow-hidden">
                <div className="aspect-[4/3] bg-black/50 relative">
                  {imagePreview ? (
                    <img src={imagePreview} className="w-full h-full object-cover" alt="Preview Cover" />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">No Cover Image</div>
                  )}
                  {formData.type && (
                     <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2 py-1 rounded text-xs font-semibold z-10">
                       {formData.type}
                     </div>
                  )}
                  {formData.mode === "Exclusive" && (
                    <div className="absolute top-12 right-3 bg-amber-500 text-black px-2 py-1 rounded text-xs font-bold z-10">
                      EXCLUSIVE
                    </div>
                  )}
                  {formData.custom_badge && (
                    <div className="absolute bottom-3 left-3 bg-indigo-500 text-white px-2 py-1 rounded text-xs font-semibold z-10">
                      {formData.custom_badge}
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h4 className="font-semibold text-lg line-clamp-1 mb-1">{formData.title || "Asset Title"}</h4>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{formData.description || "Description will appear here..."}</p>
                  
                  <div className="flex items-center justify-between mt-auto pt-3 border-t border-white/5">
                    <div className="flex flex-col">
                      {discountPct > 0 ? (
                        <>
                           <span className="text-xs text-muted-foreground line-through">${originalPrice.toFixed(2)}</span>
                           <span className="text-xl font-bold font-display text-emerald-400">
                             ${discountedPrice.toFixed(2)}
                             {formData.discount_type === "Limited Time" && (
                               <span className="ml-2 text-xs bg-red-500 text-white px-1 py-0.5 rounded animate-pulse">Limited Time</span>
                             )}
                           </span>
                        </>
                      ) : (
                        <span className="text-xl font-bold font-display">${originalPrice.toFixed(2)}</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </motion.div>
    </div>
  )
}
