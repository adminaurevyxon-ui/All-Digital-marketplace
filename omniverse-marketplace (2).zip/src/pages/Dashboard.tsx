import { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "motion/react";
import { DollarSign, Package, TrendingUp, Download, CheckCircle2, Lock, Github, RefreshCw, Code, Plus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/lib/auth";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isSuccess = searchParams.get("success") === "true";
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [loadingRepos, setLoadingRepos] = useState(false);
  const [importedRepos, setImportedRepos] = useState<any[]>([]);
  const [wishlist, setWishlist] = useState<any[]>([]);
  
  // GitHub Sync Dialog State
  const [syncOpen, setSyncOpen] = useState(false);
  const [githubRepos, setGithubRepos] = useState<any[]>([]);
  const [syncError, setSyncError] = useState("");
  
  // Payout State
  const [payoutOpen, setPayoutOpen] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState("");
  const [payoutMethod, setPayoutMethod] = useState("bank_transfer");
  const [payoutDetails, setPayoutDetails] = useState("");
  const [methods, setMethods] = useState<any[]>([]);

  const fetchMethods = () => {
    const token = localStorage.getItem("omniverse_token");
    fetch("/api/payout/methods", { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(json => setMethods(json.methods || []));
  };

  const fetchImportedRepos = () => {
    const token = localStorage.getItem("omniverse_token");
    fetch("/api/user/repos", { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(json => { setImportedRepos(json.repos || []); })
      .catch(console.error);
  };

  const fetchWishlist = () => {
    const token = localStorage.getItem("omniverse_token");
    fetch("/api/wishlists", { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(json => { setWishlist(json.wishlists || []); })
      .catch(console.error);
  };

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
      return;
    }

    const token = localStorage.getItem("omniverse_token");
    
    // Fetch Dashboard Stats
    fetch("/api/dashboard", { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(json => { setData(json); setLoading(false); })
      .catch(console.error);

    fetchImportedRepos();
    fetchMethods();
    fetchWishlist();
  }, [isAuthenticated, navigate]);

  const handleSyncGithub = async () => {
    const token = localStorage.getItem("omniverse_token");
    setLoadingRepos(true);
    setSyncError("");
    try {
      const res = await fetch("/api/github/repos", { headers: { Authorization: `Bearer ${token}` } });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed. Ensure your account is linked to GitHub.");
      
      setGithubRepos(json.repos || []);
      setSyncOpen(true);
    } catch(err: any) {
      setSyncError(err.message);
      setSyncOpen(true);
    } finally {
      setLoadingRepos(false);
    }
  };

  const handleImportRepo = async (repo: any) => {
    const token = localStorage.getItem("omniverse_token");
    try {
      const res = await fetch("/api/github/import", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          repo_id: repo.id,
          repo_name: repo.name,
          repo_url: repo.html_url,
          description: repo.description,
          language: repo.language,
          stars: repo.stars
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      // Remove from list or show success
      setGithubRepos(curr => curr.filter(r => r.id !== repo.id));
      fetchImportedRepos();
      alert("Repository imported processing started!");
    } catch (err: any) {
      alert("Import failed: " + err.message);
    }
  };

  const submitPayout = async (e: any) => {
     e.preventDefault();
     const token = localStorage.getItem("omniverse_token");
     try {
        let methodId = methods.find(m => m.method_type === payoutMethod)?.id;
        
        // If method doesn't exist, create it first
        if (!methodId) {
           const setupRes = await fetch("/api/payout/methods", {
             method: "POST",
             headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
             body: JSON.stringify({ method_type: payoutMethod, details: payoutDetails, is_default: true })
           });
           if (!setupRes.ok) throw new Error("Failed to save payout method");
           
           // refetch and find
           const methodsRes = await fetch("/api/payout/methods", { headers: { Authorization: `Bearer ${token}` } });
           const methodsJson = await methodsRes.json();
           setMethods(methodsJson.methods || []);
           methodId = methodsJson.methods[0]?.id;
        }

        const reqRes = await fetch("/api/payout/request", {
           method: "POST",
           headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
           body: JSON.stringify({ amount: parseFloat(payoutAmount), method_id: methodId })
        });
        
        const reqJson = await reqRes.json();
        if (!reqRes.ok) throw new Error(reqJson.error || "Failed");

        alert("Payout request submitted successfully!");
        setPayoutOpen(false);
        // Refresh balance
        const dashRes = await fetch("/api/dashboard", { headers: { Authorization: `Bearer ${token}` } });
        const dashJson = await dashRes.json();
        setData(dashJson);

     } catch(err: any) {
        alert(err.message);
     }
  };

  if (loading) {
     return <div className="min-h-[60vh] flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full" /></div>;
  }

  const totalSpent = data?.purchases?.reduce((acc: number, curr: any) => acc + curr.amount, 0) || 0;
  const totalEarned = data?.sales?.reduce((acc: number, curr: any) => acc + curr.amount, 0) || 0;

  return (
    <div className="container mx-auto px-4 py-12 pb-24">
       {isSuccess && (
         <div className="mb-8 bg-green-500/10 border border-green-500/30 text-green-400 p-6 rounded-2xl flex items-center gap-4">
           <CheckCircle2 className="w-8 h-8 flex-shrink-0" />
           <div>
             <h3 className="font-bold text-lg">Transaction Completed!</h3>
             <p className="text-sm opacity-80">Your payment was successful and the asset is now in your collection.</p>
           </div>
         </div>
       )}
       
       <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div className="flex items-center gap-4">
            {user?.avatar_url && (
              <img src={user.avatar_url} alt="Profile" className="w-16 h-16 rounded-full border-2 border-white/10" referrerPolicy="no-referrer" />
            )}
            <div>
              <h1 className="font-display text-4xl font-bold mb-1">Welcome Back, {user?.name}</h1>
              <p className="text-muted-foreground flex items-center gap-2">
                Manage your acquired assets and monitor your sales.
                {user?.github_username && <span className="inline-flex items-center gap-1 text-xs bg-indigo-500/20 text-indigo-400 px-2 py-1 rounded-full"><Github className="w-3 h-3"/> {user.github_username} Verified</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <Link to="/sell">
               <Button className="bg-white text-black hover:bg-gray-200">
                 Publish New Asset
               </Button>
             </Link>
          </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <Card className="bg-white/5 border-white/10">
             <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                     <DollarSign className="w-5 h-5 text-green-400" />
                  </div>
                </div>
                <p className="text-muted-foreground text-sm font-medium mb-1">Total Earned</p>
                <h3 className="text-3xl font-display font-bold">${totalEarned.toLocaleString()}</h3>
             </CardContent>
          </Card>
          
          <Card className="bg-white/5 border-white/10">
             <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center">
                     <Package className="w-5 h-5 text-indigo-400" />
                  </div>
                </div>
                <p className="text-muted-foreground text-sm font-medium mb-1">Assets Owned</p>
                <h3 className="text-3xl font-display font-bold">{data?.purchases?.length || 0}</h3>
             </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10">
             <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                     <TrendingUp className="w-5 h-5 text-blue-400" />
                  </div>
                </div>
                <p className="text-muted-foreground text-sm font-medium mb-1">Total Sales</p>
                <h3 className="text-3xl font-display font-bold">{data?.sales?.length || 0}</h3>
             </CardContent>
          </Card>

          <Card className="bg-white/5 border-indigo-500/30 bg-indigo-500/5 hover:bg-indigo-500/10 transition-colors cursor-pointer" onClick={handleSyncGithub}>
             <CardContent className="p-6 flex flex-col justify-center items-center h-full text-center">
                <Github className={`w-8 h-8 text-indigo-400 mb-3 ${loadingRepos ? 'animate-pulse' : ''}`} />
                <h3 className="font-semibold text-white mb-1">Sync GitHub</h3>
                <p className="text-xs text-muted-foreground">Import repositories & logic</p>
             </CardContent>
          </Card>
       </div>

       {/* Developer Identity / Connected Repos */}
       {importedRepos.length > 0 && (
         <div className="mb-12">
           <h2 className="text-2xl font-display font-semibold mb-6 flex items-center gap-2">
             <Code className="w-5 h-5 text-indigo-400" /> Connected Repositories
           </h2>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {importedRepos.map((repo: any) => (
                <Card key={repo.id} className="bg-white/5 border-white/10 p-5 flex flex-col hover:border-white/20 transition-colors">
                  <div className="flex items-center gap-3 mb-3">
                    <Github className="w-5 h-5 text-white" />
                    <h3 className="font-bold text-lg text-white line-clamp-1">{repo.repo_name}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-1">
                    {repo.description || "No description provided."}
                  </p>
                  <div className="flex items-center justify-between mt-4 border-t border-white/10 pt-4">
                     <span className="text-xs text-muted-foreground flex items-center gap-1">
                       <span className="w-2 h-2 rounded-full bg-indigo-400"/> {repo.language || 'Code'}
                     </span>
                     <div className="flex gap-2">
                       <a href={`https://vercel.com/new/clone?repository-url=${repo.repo_url}`} target="_blank" rel="noreferrer">
                         <Button size="sm" variant="outline" className="h-8 border-white/10 text-xs hover:bg-black hover:text-white">
                           ▲ Vercel
                         </Button>
                       </a>
                       <a href={`https://app.netlify.com/start/deploy?repository=${repo.repo_url}`} target="_blank" rel="noreferrer">
                         <Button size="sm" variant="outline" className="h-8 border-white/10 text-xs hover:bg-emerald-500 hover:text-white">
                           Netlify
                         </Button>
                       </a>
                     </div>
                  </div>
                </Card>
             ))}
           </div>
         </div>
       )}

       {/* Acquired Assets */}
       <div className="mb-12">
         <h2 className="text-2xl font-display font-semibold mb-6 flex items-center gap-2">
           <Download className="w-5 h-5 text-indigo-400" /> Acquired Assets
         </h2>
         {data?.purchases?.length === 0 ? (
           <div className="p-8 text-center rounded-2xl border border-white/5 bg-white/[0.02] text-muted-foreground">
              You haven't acquired any assets yet. <Link to="/" className="text-indigo-400 hover:underline">Explore the marketplace</Link>.
           </div>
         ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {data?.purchases?.map((purchase: any, i: number) => (
                <motion.div key={purchase.order_id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                  <Card className="bg-white/5 border-white/10 overflow-hidden flex flex-col h-full hover:border-indigo-500/30 transition-colors cursor-pointer" onClick={() => navigate(`/listing/${purchase.id}`)}>
                     <div className="h-32 bg-black/50 overflow-hidden relative">
                        <img src={purchase.image_url || purchase.image} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-medium border border-white/10">
                           {purchase.mode === "Exclusive" ? <span className="text-amber-400 flex items-center gap-1"><Lock className="w-3 h-3"/> Full Ownership</span> : "License"}
                        </div>
                     </div>
                     <CardContent className="p-4 flex-1">
                        <h3 className="font-semibold text-lg line-clamp-1 mb-1">{purchase.title}</h3>
                        <p className="text-xs text-muted-foreground">Purchased on {new Date(purchase.created_at).toLocaleDateString()}</p>
                     </CardContent>
                  </Card>
                </motion.div>
             ))}
           </div>
         )}
       </div>

       {/* Wishlist */}
       <div className="mb-12">
         <h2 className="text-2xl font-display font-semibold mb-6 flex items-center gap-2">
           <DollarSign className="w-5 h-5 text-pink-400" /> My Wishlist
         </h2>
         {wishlist?.length === 0 ? (
           <div className="p-8 text-center rounded-2xl border border-white/5 bg-white/[0.02] text-muted-foreground">
              Your wishlist is empty. Explore and save assets you like.
           </div>
         ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {wishlist?.map((item: any, i: number) => (
                <motion.div key={item.wishlist_id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                  <Card className="bg-white/5 border-white/10 overflow-hidden flex flex-col h-full hover:border-pink-500/30 transition-colors cursor-pointer" onClick={() => navigate(`/listing/${item.id}`)}>
                     <div className="h-32 bg-black/50 overflow-hidden relative">
                        <img src={item.image_url || item.image} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-medium border border-white/10">
                           {item.mode === "Exclusive" ? <span className="text-amber-400 flex items-center gap-1"><Lock className="w-3 h-3"/> Full Ownership</span> : "License"}
                        </div>
                     </div>
                     <CardContent className="p-4 flex-1">
                        <h3 className="font-semibold text-lg line-clamp-1 mb-1">{item.title}</h3>
                        <p className="text-xs text-muted-foreground">Added on {new Date(item.saved_at).toLocaleDateString()}</p>
                     </CardContent>
                  </Card>
                </motion.div>
             ))}
           </div>
         )}
       </div>

       {/* Published Assets */}
       <div className="mb-12">
         <h2 className="text-2xl font-display font-semibold mb-6 flex items-center gap-2">
           <Package className="w-5 h-5 text-indigo-400" /> Published Assets
         </h2>
         {data?.myListings?.length === 0 ? (
           <div className="p-8 text-center rounded-2xl border border-white/5 bg-white/[0.02] text-muted-foreground">
              You haven't published any assets yet.
           </div>
         ) : (
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 border-b border-white/10 text-muted-foreground">
                  <tr>
                    <th className="px-6 py-4 font-medium rounded-tl-xl">Asset</th>
                    <th className="px-6 py-4 font-medium">Price</th>
                    <th className="px-6 py-4 font-medium">Sales</th>
                    <th className="px-6 py-4 font-medium">Status</th>
                    <th className="px-6 py-4 font-medium rounded-tr-xl">Action</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                  {data?.myListings?.map((listing: any) => (
                    <tr key={listing.id} className="hover:bg-white/[0.02]">
                       <td className="px-6 py-4 font-medium max-w-[200px] truncate">{listing.title}</td>
                       <td className="px-6 py-4">${listing.price}</td>
                       <td className="px-6 py-4">{listing.sales || 0}</td>
                       <td className="px-6 py-4">
                         {listing.status === 'sold' ? (
                           <span className="text-red-400 text-xs px-2 py-1 bg-red-400/10 rounded font-medium">Sold Out</span>
                         ) : (
                           <span className="text-green-400 text-xs px-2 py-1 bg-green-400/10 rounded font-medium">Active</span>
                         )}
                       </td>
                       <td className="px-6 py-4 flex items-center gap-2">
                         <Link to={`/manage/${listing.id}`}>
                           <Button size="sm" className="bg-indigo-600 hover:bg-indigo-500 text-white h-8 text-xs px-3 shadow-[0_0_10px_rgba(79,70,229,0.3)]">Manage System</Button>
                         </Link>
                         <Link to={`/listing/${listing.id}`}>
                           <Button size="sm" variant="outline" className="border-white/10 h-8 text-xs px-3">View</Button>
                         </Link>
                       </td>
                    </tr>
                  ))}
               </tbody>
             </table>
           </div>
         )}
       </div>

       {/* Recent Sales History */}
       <div>
         <h2 className="text-2xl font-display font-semibold mb-6 flex items-center gap-2">
           <DollarSign className="w-5 h-5 text-green-400" /> Recent Sales History
         </h2>
         {data?.sales?.length === 0 ? (
           <div className="p-8 text-center rounded-2xl border border-white/5 bg-white/[0.02] text-muted-foreground">
              No sales recorded yet.
           </div>
         ) : (
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 border-b border-white/10 text-muted-foreground">
                  <tr>
                    <th className="px-6 py-4 font-medium rounded-tl-xl">Transaction ID</th>
                    <th className="px-6 py-4 font-medium">Item</th>
                    <th className="px-6 py-4 font-medium">Net Earnings</th>
                    <th className="px-6 py-4 font-medium">Platform Fee</th>
                    <th className="px-6 py-4 font-medium">Buyer</th>
                    <th className="px-6 py-4 font-medium rounded-tr-xl">Date</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                  {data?.sales?.map((sale: any) => (
                    <tr key={sale.transaction_id || sale.order_id} className="hover:bg-white/[0.02]">
                       <td className="px-6 py-4 font-mono text-xs">{sale.transaction_id || sale.order_id}</td>
                       <td className="px-6 py-4 font-medium">{sale.title}</td>
                       <td className="px-6 py-4 text-emerald-400 font-bold">+${(sale.seller_earnings ?? sale.amount)?.toFixed(2)}</td>
                       <td className="px-6 py-4 text-red-400/80">-${(sale.platform_fee ?? 0)?.toFixed(2)}</td>
                       <td className="px-6 py-4">{sale.buyer_name}</td>
                       <td className="px-6 py-4">{new Date(sale.order_date).toLocaleDateString()}</td>
                    </tr>
                  ))}
               </tbody>
             </table>
           </div>
         )}
       </div>

       {/* GitHub Sync Modal */}
       <Dialog open={syncOpen} onOpenChange={setSyncOpen}>
         <DialogContent className="sm:max-w-[700px] bg-black/90 backdrop-blur-xl border border-white/10 text-white p-0 overflow-hidden">
           <div className="p-6 pb-2 border-b border-white/10">
             <DialogHeader>
               <div className="flex items-center gap-3 mb-2">
                 <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center text-indigo-400">
                   <Github className="w-5 h-5"/>
                 </div>
                 <div>
                   <DialogTitle className="text-xl">Import from GitHub</DialogTitle>
                   <DialogDescription className="text-sm text-muted-foreground">Select repositories to link with your identity and prepare for analysis.</DialogDescription>
                 </div>
               </div>
             </DialogHeader>
           </div>
           {syncError ? (
              <div className="p-6 text-center text-red-400">{syncError}</div>
           ) : (
             <ScrollArea className="h-[400px]">
               <div className="p-4 space-y-2">
                 {githubRepos.map((repo: any) => {
                    const isImported = importedRepos.some(r => r.id === repo.id);
                    return (
                      <div key={repo.id} className="flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 rounded-lg border border-white/5 transition-colors">
                        <div className="flex-1 min-w-0 pr-4">
                          <h4 className="font-semibold text-white truncate text-base">{repo.name}</h4>
                          <p className="text-xs text-muted-foreground truncate">{repo.description || 'No description'}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-indigo-400"/> {repo.language || 'Code'}</span>
                            <span>⭐ {repo.stars}</span>
                            <span>🍴 {repo.forks}</span>
                          </div>
                        </div>
                        <Button 
                          size="sm" 
                          onClick={() => handleImportRepo(repo)}
                          disabled={isImported}
                          className={isImported ? "bg-white/10 text-white/50" : "bg-indigo-500 hover:bg-indigo-400 text-white"}
                        >
                          {isImported ? "Imported" : <><Plus className="w-4 h-4 mr-1"/> Import</>}
                        </Button>
                      </div>
                    );
                 })}
                 {githubRepos.length === 0 && !syncError && (
                    <div className="p-8 text-center text-muted-foreground">No repositories found. Make sure your GitHub account has public repositories.</div>
                 )}
               </div>
             </ScrollArea>
           )}
         </DialogContent>
       </Dialog>

       {/* Withdrawal / Payout Modal */}
       <Dialog open={payoutOpen} onOpenChange={setPayoutOpen}>
         <DialogContent className="sm:max-w-[425px] bg-black/90 backdrop-blur-xl border border-white/10 text-white p-0 overflow-hidden">
           <div className="p-6">
             <DialogHeader>
               <DialogTitle className="text-xl">Withdraw Funds</DialogTitle>
               <DialogDescription className="text-sm text-muted-foreground">Request a payout to your preferred account.</DialogDescription>
             </DialogHeader>
             
             <form onSubmit={submitPayout} className="mt-6 space-y-4">
               <div>
                  <label className="block text-sm font-medium mb-1">Amount to Withdraw (USD)</label>
                  <div className="flex justify-between text-xs text-muted-foreground mb-2">
                     <span>Available: ${data?.balance?.toFixed(2)}</span>
                     <button type="button" onClick={() => setPayoutAmount(data?.balance?.toString() || "0")} className="text-emerald-400 hover:underline">Max</button>
                  </div>
                  <input 
                    type="number" 
                    max={data?.balance} 
                    min={10} 
                    step="0.01"
                    required
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-md h-10 px-3 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
               </div>
               
               <div>
                  <label className="block text-sm font-medium mb-1">Payout Method</label>
                  <select 
                    value={payoutMethod}
                    onChange={(e) => setPayoutMethod(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-md h-10 px-3 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                     <option value="bank_transfer" className="bg-gray-900">Bank Transfer (Wire/ACH)</option>
                     <option value="paypal" className="bg-gray-900">PayPal</option>
                     <option value="crypto" className="bg-gray-900">Crypto (USDC / USDT)</option>
                     <option value="stripe" className="bg-gray-900">Stripe Connect</option>
                  </select>
               </div>
               
               {payoutMethod && (
                 <div>
                    <label className="block text-sm font-medium mb-1">Account Details</label>
                    <textarea 
                      required
                      placeholder={
                        payoutMethod === 'bank_transfer' ? "Account Name, Account Number, SWIFT/Routing" :
                        payoutMethod === 'paypal' ? "PayPal Email Address" :
                        payoutMethod === 'crypto' ? "Wallet Address (ERC20 / Polygon)" :
                        "Stripe Account ID"
                      }
                      value={payoutDetails}
                      onChange={(e) => setPayoutDetails(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-md p-3 min-h-[80px] focus:outline-none focus:ring-1 focus:ring-emerald-500 text-sm"
                    />
                 </div>
               )}
               
               <Button type="submit" disabled={!payoutAmount || Number(payoutAmount) <= 0 || Number(payoutAmount) > data?.balance} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white h-12 mt-4">
                  Confirm Withdrawal
               </Button>
             </form>
           </div>
         </DialogContent>
       </Dialog>

    </div>
  );
}
