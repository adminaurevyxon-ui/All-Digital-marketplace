import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { Users, DollarSign, Activity, FileCode, CheckCircle, XCircle, Shield, Server, Zap, Globe, Cpu, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [payouts, setPayouts] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [listings, setListings] = useState<any[]>([]);
  const [systemStats, setSystemStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!isAuthenticated) return navigate("/");
    if (user?.role !== 'admin') return navigate("/");

    const token = localStorage.getItem("omniverse_token");
    
    Promise.all([
      fetch("/api/admin/stats", { headers: { Authorization: `Bearer ${token}` } }),
      fetch("/api/admin/transactions", { headers: { Authorization: `Bearer ${token}` } }),
      fetch("/api/admin/payouts", { headers: { Authorization: `Bearer ${token}` } }),
      fetch("/api/admin/users", { headers: { Authorization: `Bearer ${token}` } }),
      fetch("/api/admin/listings", { headers: { Authorization: `Bearer ${token}` } }),
      fetch("/api/admin/system", { headers: { Authorization: `Bearer ${token}` } })
    ])
    .then(responses => Promise.all(responses.map(res => res.json())))
    .then(([statsData, txData, payoutData, usersData, listingsData, systemData]) => {
      setStats(statsData);
      setTransactions(txData.transactions || []);
      setPayouts(payoutData.payouts || []);
      setUsers(usersData.users || []);
      setListings(listingsData.listings || []);
      setSystemStats(systemData || null);
    })
    .catch(console.error)
    .finally(() => setLoading(false));

  }, [isAuthenticated, user, navigate]);

  const handlePayoutStatus = async (id: string, status: string) => {
     const token = localStorage.getItem("omniverse_token");
     if (!confirm(`Are you sure you want to mark this payout as ${status}?`)) return;
     
     try {
       const res = await fetch(`/api/admin/payouts/${id}/status`, {
         method: "POST",
         headers: {
           Authorization: `Bearer ${token}`,
           "Content-Type": "application/json"
         },
         body: JSON.stringify({ status })
       });
       if (!res.ok) throw new Error("Failed to update status");
       setPayouts(prev => prev.map(p => p.id === id ? { ...p, status } : p));
     } catch (err: any) {
       alert(err.message);
     }
  };

  const updateCommission = async (id: string) => {
    const rate = prompt("Enter new commission rate for this user (e.g., 0.15 for 15% platform fee):");
    if (!rate || isNaN(parseFloat(rate))) return;
    const token = localStorage.getItem("omniverse_token");
    try {
       const res = await fetch(`/api/admin/users/${id}/commission`, {
         method: "POST",
         headers: {
           Authorization: `Bearer ${token}`,
           "Content-Type": "application/json"
         },
         body: JSON.stringify({ rate: parseFloat(rate) })
       });
       if (!res.ok) throw new Error("Update failed");
       setUsers(prev => prev.map(u => u.id === id ? { ...u, commission_rate: parseFloat(rate) } : u));
    } catch (err: any) {
       alert(err.message);
    }
  };

  const toggleUserStatus = async (id: string, field: string, currentValue: boolean) => {
     const token = localStorage.getItem("omniverse_token");
     try {
       const res = await fetch(`/api/admin/users/${id}/status`, {
         method: "POST",
         headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
         body: JSON.stringify({ [field]: !currentValue })
       });
       if (!res.ok) throw new Error("Update failed");
       setUsers(prev => prev.map(u => u.id === id ? { ...u, [field]: !currentValue } : u));
     } catch (err: any) { alert(err.message); }
  };

  const toggleListingStatus = async (id: string, field: string, currentValue: boolean) => {
     const token = localStorage.getItem("omniverse_token");
     try {
       const res = await fetch(`/api/admin/listings/${id}/status`, {
         method: "POST",
         headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
         body: JSON.stringify({ [field]: !currentValue })
       });
       if (!res.ok) throw new Error("Update failed");
       setListings(prev => prev.map(l => l.id === id ? { ...l, [field]: !currentValue } : l));
     } catch (err: any) { alert(err.message); }
  };

  const deleteListing = async (id: string) => {
     if(!confirm("DELETE ENTIRE LISTING FOREVER?")) return;
     const token = localStorage.getItem("omniverse_token");
     try {
       const res = await fetch(`/api/admin/listings/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
       if (!res.ok) throw new Error("Delete failed");
       setListings(prev => prev.filter(l => l.id !== id));
     } catch (err: any) { alert(err.message); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
         <div className="relative">
            <div className="absolute inset-0 bg-indigo-500 blur-[50px] opacity-20 rounded-full"></div>
            <div className="animate-spin w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Zap className="w-6 h-6 text-indigo-400 animate-pulse" />
            </div>
         </div>
      </div>
    );
  }

  const mockRevenueData = [
    { name: 'Mon', revenue: stats?.totalRevenue * 0.1 || 1200, users: 400 },
    { name: 'Tue', revenue: stats?.totalRevenue * 0.15 || 1900, users: 300 },
    { name: 'Wed', revenue: stats?.totalRevenue * 0.2 || 2400, users: 550 },
    { name: 'Thu', revenue: stats?.totalRevenue * 0.25 || 2800, users: 600 },
    { name: 'Fri', revenue: stats?.totalRevenue * 0.1 || 1100, users: 450 },
    { name: 'Sat', revenue: stats?.totalRevenue * 0.05 || 800, users: 700 },
    { name: 'Sun', revenue: stats?.totalRevenue * 0.15 || 2100, users: 900 },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-[#F0F0FF] selection:bg-indigo-500/30 font-sans pb-20 relative overflow-hidden">
       {/* Cyber Background */}
       <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/10 blur-[120px] rounded-full mix-blend-screen" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-cyan-600/10 blur-[120px] rounded-full mix-blend-screen" />
          <div className="absolute top-[40%] left-[60%] w-[30%] h-[30%] bg-purple-600/10 blur-[100px] rounded-full mix-blend-screen" />
       </div>

       <div className="max-w-7xl mx-auto px-6 py-12 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-end mb-10"
        >
          <div>
            <div className="flex items-center gap-3 mb-2">
               <Shield className="w-8 h-8 text-indigo-400" />
               <h1 className="font-display text-4xl lg:text-5xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400 drop-shadow-[0_0_15px_rgba(99,102,241,0.3)]">
                 OMEGA-NEXUS 
               </h1>
            </div>
            <p className="text-indigo-200/60 tracking-[0.2em] text-xs uppercase ml-11 font-mono flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              God-Mode Command Center
            </p>
          </div>
          <div className="hidden lg:flex items-center gap-4 bg-white/5 border border-white/10 px-4 py-2 rounded-xl backdrop-blur-md">
             <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-mono text-emerald-400">GLOBAL CLUSTER: NOMINAL</span>
             </div>
             <div className="w-px h-4 bg-white/20 mx-2" />
             <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-mono text-cyan-400">EDGE NODES: ONLINE</span>
             </div>
          </div>
        </motion.div>

        {/* Sub-Nav */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-none">
          {['overview', 'transactions', 'payouts', 'users', 'products', 'system'].map(tab => (
             <button 
               key={tab} 
               onClick={() => setActiveTab(tab)}
               className={`uppercase text-xs font-bold tracking-widest px-6 py-3 rounded-lg transition-all whitespace-nowrap 
                 ${activeTab === tab 
                   ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.2)]' 
                   : 'bg-white/[0.02] border border-white/5 text-muted-foreground hover:bg-white/[0.05] hover:text-white'}`}
             >
               {tab}
             </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
           {activeTab === 'overview' && (
             <div className="space-y-6">
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card className="bg-[#141428]/80 backdrop-blur-xl border-white/10 hover:border-indigo-400/50 transition-all shadow-lg hover:shadow-indigo-500/10 group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/0 to-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <CardContent className="p-6 relative z-10">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase text-indigo-300/70 tracking-wider mb-2 font-mono">Platform Revenue</p>
                          <h3 className="text-3xl font-display font-bold text-white drop-shadow-md">${stats?.platformEarnings?.toLocaleString(undefined, {minimumFractionDigits: 2}) || "0.00"}</h3>
                        </div>
                        <div className="w-12 h-12 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(99,102,241,0.2)]"><DollarSign className="w-6 h-6"/></div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-[#141428]/80 backdrop-blur-xl border-white/10 hover:border-emerald-400/50 transition-all shadow-lg hover:shadow-emerald-500/10 group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/0 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <CardContent className="p-6 relative z-10">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase text-emerald-300/70 tracking-wider mb-2 font-mono">Gross Volume</p>
                          <h3 className="text-3xl font-display font-bold text-white drop-shadow-md">${stats?.totalRevenue?.toLocaleString(undefined, {minimumFractionDigits: 2}) || "0.00"}</h3>
                        </div>
                        <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.2)]"><Activity className="w-6 h-6"/></div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#141428]/80 backdrop-blur-xl border-white/10 hover:border-cyan-400/50 transition-all shadow-lg hover:shadow-cyan-500/10 group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/0 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <CardContent className="p-6 relative z-10">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase text-cyan-300/70 tracking-wider mb-2 font-mono">Global Users</p>
                          <h3 className="text-3xl font-display font-bold text-white drop-shadow-md">{stats?.activeUsers?.toLocaleString() || "0"}</h3>
                        </div>
                        <div className="w-12 h-12 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.2)]"><Users className="w-6 h-6"/></div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#141428]/80 backdrop-blur-xl border-white/10 hover:border-purple-400/50 transition-all shadow-lg hover:shadow-purple-500/10 group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500/0 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <CardContent className="p-6 relative z-10">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase text-purple-300/70 tracking-wider mb-2 font-mono">Total Assets</p>
                          <h3 className="text-3xl font-display font-bold text-white drop-shadow-md">{stats?.productsCount?.toLocaleString() || "0"}</h3>
                        </div>
                        <div className="w-12 h-12 bg-purple-500/10 border border-purple-500/20 text-purple-400 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.2)]"><FileCode className="w-6 h-6"/></div>
                      </div>
                    </CardContent>
                  </Card>
               </div>

               {/* Charts Section */}
               <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                 <Card className="lg:col-span-2 bg-[#141428]/80 backdrop-blur-md border-white/10">
                    <CardHeader className="border-b border-white/5 pb-4">
                      <CardTitle className="text-sm font-bold tracking-widest text-indigo-200">REVENUE VELOCITY (7D)</CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={mockRevenueData}>
                          <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                          <XAxis dataKey="name" stroke="rgba(255,255,255,0.2)" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis stroke="rgba(255,255,255,0.2)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                          <RechartsTooltip 
                            contentStyle={{ backgroundColor: 'rgba(20, 20, 40, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                            itemStyle={{ color: '#fff' }}
                          />
                          <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </CardContent>
                 </Card>
                 <Card className="bg-[#141428]/80 backdrop-blur-md border-white/10 flex flex-col">
                    <CardHeader className="border-b border-white/5 pb-4">
                      <CardTitle className="text-sm font-bold tracking-widest text-cyan-200">PLATFORM METRICS</CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 flex-1 flex flex-col justify-between">
                       <div className="space-y-6">
                         <div>
                            <div className="flex justify-between text-xs mb-2 font-mono">
                              <span className="text-muted-foreground">Global Conversion Rate</span>
                              <span className="text-emerald-400 font-bold">{stats?.conversionRate || "5.2%"}</span>
                            </div>
                            <div className="w-full bg-white/5 rounded-full h-1.5"><div className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-1.5 rounded-full w-[45%]"></div></div>
                         </div>
                         <div>
                            <div className="flex justify-between text-xs mb-2 font-mono">
                              <span className="text-muted-foreground">Active Listings</span>
                              <span className="text-indigo-400 font-bold">{stats?.activeListings || "0"}</span>
                            </div>
                            <div className="w-full bg-white/5 rounded-full h-1.5"><div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-1.5 rounded-full w-[70%]"></div></div>
                         </div>
                         <div>
                            <div className="flex justify-between text-xs mb-2 font-mono">
                              <span className="text-muted-foreground">Pending Approvals</span>
                              <span className="text-orange-400 font-bold">{stats?.pendingListings || "0"}</span>
                            </div>
                            <div className="w-full bg-white/5 rounded-full h-1.5"><div className="bg-gradient-to-r from-orange-500 to-red-500 h-1.5 rounded-full w-[15%]"></div></div>
                         </div>
                       </div>
                    </CardContent>
                 </Card>
               </div>
             </div>
           )}

           {activeTab === 'transactions' && (
             <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="bg-[#141428]/80 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-2xl">
               <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 text-xs uppercase tracking-wider text-muted-foreground">
                 <tr>
                   <th className="px-6 py-4">Transaction ID</th>
                   <th className="px-6 py-4">Item</th>
                   <th className="px-6 py-4">Amount</th>
                   <th className="px-6 py-4">Platform Fee</th>
                   <th className="px-6 py-4">Seller Earnings</th>
                   <th className="px-6 py-4">Buyer / Seller</th>
                   <th className="px-6 py-4">Date</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                 {transactions.map(tx => (
                   <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                     <td className="px-6 py-4 font-mono text-xs text-muted-foreground">{tx.id}</td>
                     <td className="px-6 py-4 font-medium">{tx.product_title}</td>
                     <td className="px-6 py-4 text-emerald-400 font-medium">${tx.amount.toFixed(2)}</td>
                     <td className="px-6 py-4 text-indigo-400">${tx.platform_fee.toFixed(2)}</td>
                     <td className="px-6 py-4">${tx.seller_earnings.toFixed(2)}</td>
                     <td className="px-6 py-4">
                       <span className="text-xs text-muted-foreground block">B: {tx.buyer_name}</span>
                       <span className="text-xs text-muted-foreground block">S: {tx.seller_name}</span>
                     </td>
                     <td className="px-6 py-4 text-xs text-muted-foreground">{new Date(tx.created_at).toLocaleString()}</td>
                   </tr>
                 ))}
                 {transactions.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">No transactions yet</td></tr>}
               </tbody>
             </table>
           </div>
         </motion.div>
       )}

           {activeTab === 'payouts' && (
             <motion.div initial={{opacity:0}} animate={{opacity:1}} className="bg-[#141428]/80 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-2xl">
               <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 text-xs uppercase tracking-wider text-muted-foreground">
                 <tr>
                   <th className="px-6 py-4">Request ID</th>
                   <th className="px-6 py-4">User</th>
                   <th className="px-6 py-4">Amount</th>
                   <th className="px-6 py-4">Method & Details</th>
                   <th className="px-6 py-4">Status</th>
                   <th className="px-6 py-4">Date</th>
                   <th className="px-6 py-4 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                 {payouts.map(p => (
                   <tr key={p.id} className="hover:bg-white/5 transition-colors">
                     <td className="px-6 py-4 font-mono text-xs text-muted-foreground">{p.id}</td>
                     <td className="px-6 py-4">
                       <span className="font-medium">{p.user_name}</span>
                       <div className="text-xs text-muted-foreground">{p.email}</div>
                     </td>
                     <td className="px-6 py-4 font-bold text-emerald-400">${p.amount.toFixed(2)}</td>
                     <td className="px-6 py-4">
                       <span className="uppercase text-xs font-bold bg-white/10 px-2 py-1 rounded inline-block mb-1">{p.method_type}</span>
                       <div className="text-xs text-muted-foreground whitespace-pre-wrap">{p.details}</div>
                     </td>
                     <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-bold uppercase
                           ${p.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' :
                             p.status === 'pending' ? 'bg-orange-500/20 text-orange-400' :
                             'bg-red-500/20 text-red-400'}
                        `}>
                           {p.status}
                        </span>
                     </td>
                     <td className="px-6 py-4 text-xs text-muted-foreground">{new Date(p.created_at).toLocaleString()}</td>
                     <td className="px-6 py-4 text-right">
                       {p.status === 'pending' && (
                         <div className="flex gap-2 justify-end">
                           <Button size="sm" onClick={() => handlePayoutStatus(p.id, 'completed')} className="bg-emerald-500 hover:bg-emerald-600 text-white"><CheckCircle className="w-4 h-4"/></Button>
                           <Button size="sm" onClick={() => handlePayoutStatus(p.id, 'rejected')} className="bg-red-500 hover:bg-red-600 text-white"><XCircle className="w-4 h-4"/></Button>
                         </div>
                       )}
                     </td>
                   </tr>
                 ))}
                 {payouts.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">No payout requests</td></tr>}
               </tbody>
             </table>
           </div>
         </motion.div>
       )}

       {activeTab === 'users' && (
         <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="bg-[#141428]/80 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-2xl">
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 text-xs uppercase tracking-wider text-muted-foreground">
                 <tr>
                   <th className="px-6 py-4">User</th>
                   <th className="px-6 py-4">Role / Provider</th>
                   <th className="px-6 py-4">Balance</th>
                   <th className="px-6 py-4">Commission Rate</th>
                   <th className="px-6 py-4 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                 {users.map(u => (
                   <tr key={u.id} className="hover:bg-white/5 transition-colors">
                     <td className="px-6 py-4">
                       <span className="font-medium block">{u.name}</span>
                       <span className="text-xs text-muted-foreground block">{u.email}</span>
                     </td>
                     <td className="px-6 py-4">
                       <span className="text-xs uppercase bg-white/10 px-2 py-1 rounded inline-block mr-2">{u.role}</span>
                       <span className="text-xs text-muted-foreground">{u.provider}</span>
                     </td>
                     <td className="px-6 py-4 font-bold text-emerald-400">${u.seller_balance?.toFixed(2) || '0.00'}</td>
                     <td className="px-6 py-4">
                       {((u.commission_rate || 0.25) * 100).toFixed(0)}% Platform Fee
                       {u.is_verified ? <CheckCircle className="w-4 h-4 text-emerald-400 inline ml-2" /> : null}
                     </td>
                     <td className="px-6 py-4 text-right">
                       <div className="flex gap-2 justify-end">
                         <Button size="sm" variant="outline" onClick={() => updateCommission(u.id)} className="h-8 border-white/10 text-xs">
                           Adjust Rate
                         </Button>
                         <Button size="sm" variant={u.is_banned ? "destructive" : "outline"} onClick={() => toggleUserStatus(u.id, 'is_banned', u.is_banned)} className={`h-8 text-xs ${u.is_banned ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30' : 'border-white/10 hover:bg-red-500/20 hover:text-red-400'}`}>
                           {u.is_banned ? 'Banned' : 'Ban'}
                         </Button>
                       </div>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
         </motion.div>
       )}

       {activeTab === 'products' && (
         <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="bg-[#141428]/80 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-2xl">
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-white/5 text-xs uppercase tracking-wider text-muted-foreground">
                 <tr>
                   <th className="px-6 py-4">Product</th>
                   <th className="px-6 py-4">Seller</th>
                   <th className="px-6 py-4">Price</th>
                   <th className="px-6 py-4">Status</th>
                   <th className="px-6 py-4 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-white/5">
                 {listings.map(l => (
                   <tr key={l.id} className="hover:bg-white/5 transition-colors">
                     <td className="px-6 py-4">
                       <span className="font-medium block">{l.title}</span>
                       <span className="text-xs text-muted-foreground block font-mono">{l.id}</span>
                     </td>
                     <td className="px-6 py-4">
                       <span className="font-medium">{l.seller_name}</span>
                       <div className="text-xs text-muted-foreground">{l.seller_email}</div>
                     </td>
                     <td className="px-6 py-4 font-bold text-emerald-400">${l.price}</td>
                     <td className="px-6 py-4">
                       <div className="flex gap-2">
                         <span className={`text-xs px-2 py-1 rounded font-bold uppercase ${l.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-orange-500/20 text-orange-400'}`}>{l.status}</span>
                         {l.is_featured ? <span className="text-xs px-2 py-1 rounded bg-indigo-500/20 text-indigo-400 font-bold uppercase">Featured</span> : null}
                         {!l.is_approved ? <span className="text-xs px-2 py-1 rounded bg-red-500/20 text-red-500 font-bold uppercase">Hidden</span> : null}
                       </div>
                     </td>
                     <td className="px-6 py-4 text-right">
                       <div className="flex gap-2 justify-end">
                         <Button size="sm" variant="outline" onClick={() => toggleListingStatus(l.id, 'is_featured', l.is_featured)} className="h-8 border-white/10 text-xs">
                           {l.is_featured ? 'Unfeature' : 'Feature'}
                         </Button>
                         <Button size="sm" variant="outline" onClick={() => toggleListingStatus(l.id, 'is_approved', l.is_approved)} className="h-8 border-white/10 text-xs">
                           {l.is_approved ? 'Hide' : 'Approve'}
                         </Button>
                         <Button size="sm" onClick={() => deleteListing(l.id)} className="bg-red-500/20 text-red-500 hover:bg-red-500 hover:text-white h-8 border border-red-500/20 text-xs">
                           Delete
                         </Button>
                       </div>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
         </motion.div>
       )}

       {activeTab === 'system' && systemStats && (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                 <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">Infrastructure Health</h4>
                 <div className="space-y-4">
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Database Size</span>
                       <span className="font-mono text-emerald-400">{(systemStats.dbSize / 1024 / 1024).toFixed(2)} MB</span>
                     </div>
                     <div className="w-full bg-white/5 rounded-full h-1"><div className="bg-emerald-500 h-1 rounded-full" style={{width: '12%'}}></div></div>
                   </div>
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Uptime</span>
                       <span className="font-mono text-indigo-400">{(systemStats.uptime / 3600).toFixed(2)} Hours</span>
                     </div>
                   </div>
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Platform</span>
                       <span className="font-mono">{systemStats.platform}</span>
                     </div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Node Version</span>
                       <span className="font-mono">{systemStats.nodeVersion}</span>
                     </div>
                   </div>
                 </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                 <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">Memory Usage</h4>
                 <div className="space-y-4">
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>RSS</span>
                       <span className="font-mono">{(systemStats.memory.rss / 1024 / 1024).toFixed(2)} MB</span>
                     </div>
                     <div className="w-full bg-white/5 rounded-full h-1"><div className="bg-purple-500 h-1 rounded-full" style={{width: `${Math.min((systemStats.memory.rss / 512 / 1024 / 1024) * 100, 100)}%`}}></div></div>
                   </div>
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Heap Total</span>
                       <span className="font-mono text-blue-400">{(systemStats.memory.heapTotal / 1024 / 1024).toFixed(2)} MB</span>
                     </div>
                   </div>
                   <div>
                     <div className="flex justify-between text-sm mb-1">
                       <span>Heap Used</span>
                       <span className="font-mono text-orange-400">{(systemStats.memory.heapUsed / 1024 / 1024).toFixed(2)} MB</span>
                     </div>
                     <div className="w-full bg-white/5 rounded-full h-1"><div className="bg-orange-500 h-1 rounded-full" style={{width: `${(systemStats.memory.heapUsed / systemStats.memory.heapTotal) * 100}%`}}></div></div>
                   </div>
                 </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-indigo-500/20 to-purple-500/10 border-indigo-500/30">
               <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
                  <Activity className="w-12 h-12 text-indigo-400 mb-4" />
                  <h3 className="font-display font-bold text-xl mb-2">Systems Nominal</h3>
                  <p className="text-sm text-indigo-200">Zero-Crash architecture is engaged. All global nodes are responding normally.</p>
               </CardContent>
            </Card>
         </div>
       )}
        </motion.div>
      </AnimatePresence>
       </div>
    </div>
  );
}
