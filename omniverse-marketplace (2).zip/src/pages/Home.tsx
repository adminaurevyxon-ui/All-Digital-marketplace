import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, Star, Shield, Zap, Lock, Download, ChevronRight, User, Search, CheckCircle, Filter, Smartphone, Globe } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/lib/currency";
import { Heart } from "lucide-react";
import { useAuth } from "@/lib/auth";

interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  type: string;
  mode: "Exclusive" | "Unlimited";
  sales: number;
  rating: number;
  author: string;
  image_url: string;
  image: string;
  tags: string[];
  is_verified?: boolean;
  is_featured?: boolean;
  discount_percentage?: number;
  discount_type?: "None" | "Limited Time" | "Unlimited";
  custom_badge?: string;
  screenshots?: string;
  seller_id?: string;
}

export default function Home() {
  const { user } = useAuth();
  const currentUserId = user?.id;
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") || "";
  const categoryFilter = searchParams.get("category") || "All";
  const modeFilter = searchParams.get("mode") || "All";
  const minPriceFilter = searchParams.get("minPrice") || "";
  const maxPriceFilter = searchParams.get("maxPrice") || "";
  
  const [listings, setListings] = useState<Listing[]>([]);

  useEffect(() => {
    let url = `/api/listings?q=${encodeURIComponent(q)}`;
    if (categoryFilter !== "All") url += `&category=${encodeURIComponent(categoryFilter)}`;
    if (modeFilter !== "All") url += `&mode=${encodeURIComponent(modeFilter)}`;
    if (minPriceFilter) url += `&minPrice=${encodeURIComponent(minPriceFilter)}`;
    if (maxPriceFilter) url += `&maxPrice=${encodeURIComponent(maxPriceFilter)}`;

    fetch(url)
      .then((res) => res.json())
      .then((data) => setListings(data.listings))
      .catch((err) => console.error(err));
  }, [q, categoryFilter, modeFilter, minPriceFilter, maxPriceFilter]);

  const updateFilter = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value && value !== "All") {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  const exclusiveListings = listings.filter((l) => l.mode === "Exclusive");
  const unlimitedListings = listings.filter((l) => l.mode === "Unlimited");
  
  const mobileApps = listings.filter((l) => l.type === "Mobile App");
  const websites = listings.filter((l) => l.type === "Website");

  const renderCategorizedGrid = () => {
    if (categoryFilter === "Mobile App") {
       return (
         <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
           {listings.map((listing, i) => (
             <PlayStoreCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
           ))}
         </div>
       );
    } else if (categoryFilter === "Website") {
       return (
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           {listings.map((listing, i) => (
             <WebsiteCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
           ))}
         </div>
       );
    } else {
       return (
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
           {listings.map((listing, i) => (
             <ListingCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
           ))}
         </div>
       );
    }
  };

  return (
    <div className="flex flex-col gap-16 pb-20">
      {/* Hero Section */}
      {!q && categoryFilter === "All" && (
      <section className="relative pt-24 pb-32 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-500/20 rounded-full blur-[120px] opacity-50 pointer-events-none" />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="container relative z-10 mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="outline" className="mb-6 py-1.5 px-4 backdrop-blur-md bg-white/5 border-white/10 text-indigo-300 font-medium">
              <Zap className="w-3.5 h-3.5 mr-2 inline-block" />
              The Next-Gen Digital Economy
            </Badge>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight mb-8 leading-[1.1]">
              Buy & Sell <br />
              <span className="text-gradient-primary">Premium Digital Assets</span>
            </h1>
            <p className="text-xl text-muted-foreground/80 max-w-2xl mx-auto mb-10 leading-relaxed">
              The ultimate marketplace for full businesses, SaaS platforms, AI systems, source codes, and premium UI kits. Acquire exclusive ownership or scale unlimited products.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="h-14 px-8 rounded-full text-base font-medium w-full sm:w-auto bg-white text-black hover:bg-gray-200">
                Explore Marketplace <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Link to="/sell" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="h-14 px-8 rounded-full text-base font-medium w-full border-white/10 hover:bg-white/5">
                  Start Selling
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
      )}

      {/* Universal Search & Filter Bar */}
      <section className="container mx-auto px-4 mt-8">
        <div className="glass-card border border-white/5 bg-white/[0.02] rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center">
           <div className="relative flex-1 w-full">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
             <Input 
               placeholder="Search premium digital assets..." 
               value={q}
               onChange={(e) => updateFilter("q", e.target.value)}
               className="w-full pl-10 bg-white/5 border-white/10 h-12"
             />
           </div>
           
           <div className="flex flex-wrap md:flex-nowrap gap-3 w-full md:w-auto">
             <Select value={categoryFilter} onValueChange={(val) => updateFilter("category", val)}>
               <SelectTrigger className="w-full md:w-[160px] h-12 bg-white/5 border-white/10">
                 <SelectValue placeholder="Category" />
               </SelectTrigger>
               <SelectContent>
                 <SelectItem value="All">All Categories</SelectItem>
                 <SelectItem value="Mobile App">Mobile Apps</SelectItem>
                 <SelectItem value="AI System">AI Systems</SelectItem>
                 <SelectItem value="Website">Full Websites</SelectItem>
                 <SelectItem value="SaaS Platform">SaaS Platforms</SelectItem>
                 <SelectItem value="Source Code">Source Code</SelectItem>
                 <SelectItem value="UI Kit">UI/UX Kits</SelectItem>
               </SelectContent>
             </Select>

             <Select value={modeFilter} onValueChange={(val) => updateFilter("mode", val)}>
               <SelectTrigger className="w-full md:w-[140px] h-12 bg-white/5 border-white/10">
                 <SelectValue placeholder="Sale Mode" />
               </SelectTrigger>
               <SelectContent>
                 <SelectItem value="All">All Modes</SelectItem>
                 <SelectItem value="Exclusive">Exclusive</SelectItem>
                 <SelectItem value="Unlimited">Unlimited</SelectItem>
               </SelectContent>
             </Select>
             
             <div className="flex items-center gap-2 w-full md:w-auto">
               <Input 
                 type="number"
                 placeholder="Min $"
                 value={minPriceFilter}
                 onChange={(e) => updateFilter("minPrice", e.target.value)}
                 className="w-full md:w-20 lg:w-24 h-12 bg-white/5 border-white/10"
               />
               <span className="text-muted-foreground">-</span>
               <Input 
                 type="number"
                 placeholder="Max $"
                 value={maxPriceFilter}
                 onChange={(e) => updateFilter("maxPrice", e.target.value)}
                 className="w-full md:w-20 lg:w-24 h-12 bg-white/5 border-white/10"
               />
             </div>
           </div>
        </div>
      </section>

      {/* When filtering explicitly by search or category */}
      {(q || categoryFilter !== "All" || modeFilter !== "All" || minPriceFilter || maxPriceFilter) && (
        <section className="pt-4 px-4 container mx-auto">
           <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
              <h2 className="text-2xl font-display font-medium flex items-center gap-3">
                <Filter className="text-indigo-400 w-5 h-5" />
                {categoryFilter !== "All" ? `${categoryFilter}s` : "Search Results"}
              </h2>
              <Button onClick={() => { setSearchParams(new URLSearchParams()); }} variant="ghost" className="text-sm">
                Clear Filters
              </Button>
           </div>
           
           {listings.length > 0 ? (
             renderCategorizedGrid()
           ) : (
             <div className="py-20 text-center glass-card border border-white/5 rounded-2xl">
               <p className="text-muted-foreground text-lg">No assets found matching your criteria.</p>
               <Button onClick={() => { setSearchParams(new URLSearchParams()); }} variant="outline" className="mt-4 border-white/10 hover:bg-white/5">
                 Clear All Filters
               </Button>
             </div>
           )}
        </section>
      )}

      {!q && categoryFilter === "All" && !minPriceFilter && !maxPriceFilter && modeFilter === "All" && (
        <>
      {/* Trust Badges */}
      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="container mx-auto px-4 py-8">
           <div className="flex flex-wrap justify-center gap-12 sm:gap-24 opacity-60 grayscale brightness-200">
              <div className="flex items-center gap-2 font-display font-bold text-xl"><Shield className="w-6 h-6"/> SECURE ESCROW</div>
              <div className="flex items-center gap-2 font-display font-bold text-xl"><Lock className="w-6 h-6"/> BLOCKCHAIN VERIFIED</div>
              <div className="flex items-center gap-2 font-display font-bold text-xl"><Zap className="w-6 h-6"/> INSTANT TRANSFER</div>
           </div>
        </div>
      </section>

      {/* Featured Listings */}
      {listings.filter(l => l.is_featured).length > 0 && !q && (
      <section className="container mx-auto px-4 mt-12 mb-4">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold mb-2 flex items-center gap-3">
              <span className="bg-gradient-to-r from-pink-500/20 to-indigo-500/20 text-pink-400 p-2 rounded-lg">
                <Star className="w-6 h-6 fill-pink-500" />
              </span>
              Featured Assets
            </h2>
            <p className="text-muted-foreground">Handpicked premium products across all categories.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {listings.filter(l => l.is_featured).slice(0, 4).map((listing, i) => (
             <ListingCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
          ))}
        </div>
      </section>
      )}

          {/* Dedicated Play Store Section */}
          {mobileApps.length > 0 && (
          <section className="container mx-auto px-4 mt-8">
            <div className="flex items-end justify-between mb-8">
              <div>
                <h2 className="font-display text-3xl font-bold mb-2 flex items-center gap-3">
                  <span className="bg-green-500/20 text-green-400 p-2 rounded-lg shadow-[0_0_15px_rgba(34,197,94,0.3)]"><Smartphone className="w-5 h-5" /></span>
                  App Marketplace
                </h2>
                <p className="text-muted-foreground">Premium mobile apps and templates ready to launch.</p>
              </div>
              <Button variant="ghost" onClick={() => updateFilter("category", "Mobile App")} className="hidden sm:flex group">
                Open App Store <ChevronRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {mobileApps.slice(0, 6).map((listing, i) => (
                <PlayStoreCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
              ))}
            </div>
          </section>
          )}

          {/* Dedicated Website Section */}
          {websites.length > 0 && (
          <section className="container mx-auto px-4 mt-8">
            <div className="flex items-end justify-between mb-8">
              <div>
                <h2 className="font-display text-3xl font-bold mb-2 flex items-center gap-3">
                  <span className="bg-blue-500/20 text-blue-400 p-2 rounded-lg shadow-[0_0_15px_rgba(59,130,246,0.3)]"><Globe className="w-5 h-5" /></span>
                  Website & Portals
                </h2>
                <p className="text-muted-foreground">High-converting websites and scalable SaaS frontends.</p>
              </div>
              <Button variant="ghost" onClick={() => updateFilter("category", "Website")} className="hidden sm:flex group">
                Browse Websites <ChevronRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {websites.slice(0, 4).map((listing, i) => (
                <WebsiteCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
              ))}
            </div>
          </section>
          )}

      {/* Exclusive Acquisitions */}
      {exclusiveListings.length > 0 && (
      <section className="container mx-auto px-4 mt-8">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="font-display text-3xl font-bold mb-2 flex items-center gap-3">
              <span className="bg-amber-500/20 text-amber-400 p-2 rounded-lg"><Lock className="w-6 h-6" /></span>
              Exclusive Acquisitions
            </h2>
            <p className="text-muted-foreground">One-time sales. Full ownership transfer. NDAs included.</p>
          </div>
          <Button variant="ghost" className="hidden sm:flex group">
            View All <ChevronRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exclusiveListings.map((listing, i) => (
             <ListingCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
          ))}
        </div>
      </section>
      )}

      {/* Unlimited Digital Products */}
      {unlimitedListings.length > 0 && (
      <section className="container mx-auto px-4 mt-8">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="font-display text-3xl font-bold mb-2 flex items-center gap-3">
              <span className="bg-indigo-500/20 text-indigo-400 p-2 rounded-lg"><Download className="w-6 h-6" /></span>
              Digital Assets
            </h2>
            <p className="text-muted-foreground">Unlimited licensing. Apps, UI kits, AI prompts, and more.</p>
          </div>
          <Button variant="ghost" className="hidden sm:flex group">
            Browse Market <ChevronRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {unlimitedListings.map((listing, i) => (
             <ListingCard key={listing.id} listing={listing} i={i} currentUserId={currentUserId} />
          ))}
        </div>
      </section>
      )}
        </>
      )}
      
      {/* CTA Section */}
      <section className="container mx-auto px-4 mt-12">
        <div className="rounded-3xl glass-card border border-white/10 p-10 md:p-20 relative overflow-hidden text-center">
           <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500/20 rounded-full blur-[100px] pointer-events-none" />
           <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-pink-500/10 rounded-full blur-[100px] pointer-events-none" />
           
           <h2 className="font-display text-4xl md:text-5xl font-bold mb-6 relative z-10">Ready to Monopolize Your Code?</h2>
           <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 relative z-10">
             Join 50,000+ ultimate creators selling premium digital real estate. Access the billion-dollar digital economy platform.
           </p>
           <div className="flex flex-col sm:flex-row justify-center gap-4 relative z-10">
             <Link to="/sell" className="w-full sm:w-auto">
               <Button size="lg" className="w-full h-14 px-8 rounded-full text-base font-medium xl">
                 Become a Seller Today
               </Button>
             </Link>
             <Button size="lg" variant="outline" className="h-14 px-8 rounded-full text-base font-medium border-white/10 bg-black/50">
               Explore AI Systems
             </Button>
           </div>
        </div>
      </section>
    </div>
  );
}

function ListingCard({ listing, i, currentUserId }: { key?: string | number, listing: Listing; i: number; currentUserId?: string }) {
  const { convert } = useCurrency();
  const [inWishlist, setInWishlist] = useState(false);

  // Initial check could be done if we passed it down, but for now we just handle toggle
  const toggleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const token = localStorage.getItem("omniverse_token");
    if (!token) {
        alert("Please login to use wishlist");
        return;
    }
    
    try {
      const res = await fetch(`/api/wishlists/${listing.id}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.status === "added") setInWishlist(true);
      else if (data.status === "removed") setInWishlist(false);
    } catch(err) {
      console.error(err);
    }
  };

  const discountPct = listing.discount_percentage || 0;
  const discountedPrice = listing.price - (listing.price * (discountPct / 100));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.1 }}
    >
      <Link to={`/listing/${listing.id}`} className="block group">
        <Card className="bg-black/40 border-white/5 hover:bg-white/[0.02] hover:border-indigo-500/30 transition-all duration-300 h-full flex flex-col relative">
          
          <button 
            onClick={toggleWishlist}
            className="absolute top-3 right-3 z-30 p-2 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md transition-colors"
          >
            <Heart className={`w-4 h-4 ${inWishlist ? "fill-pink-500 text-pink-500" : "text-white"}`} />
          </button>

          <div className="relative aspect-[4/3] overflow-hidden rounded-t-xl bg-black/50">
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
            <img 
              src={listing.image_url || listing.image} 
              alt={listing.title}
              referrerPolicy="no-referrer"
              className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
            />
            <Badge variant="secondary" className="absolute top-3 left-3 bg-black/70 backdrop-blur-md border-white/10 z-20">
              {listing.type}
            </Badge>
            {listing.mode === "Exclusive" && (
              <Badge className="absolute top-12 right-3 bg-amber-500 text-black hover:bg-amber-400 font-semibold border-none z-20">
                EXCLUSIVE
              </Badge>
            )}
            {listing.is_featured ? (
              <Badge className="absolute top-12 left-3 bg-indigo-500 text-white border-none z-20">
                FEATURED
              </Badge>
            ) : null}
            {listing.custom_badge && (
              <Badge className="absolute bottom-3 left-3 bg-pink-500 text-white border-none z-20">
                {listing.custom_badge}
              </Badge>
            )}
            {discountPct > 0 && listing.discount_type === "Limited Time" && (
              <Badge className="absolute top-3 right-12 bg-red-500 text-white border-none z-20 animate-pulse">
                {discountPct}% OFF (Limited Time)
              </Badge>
            )}
          </div>
          <CardContent className="p-4 flex-1">
            <h3 className="font-display font-medium text-base mb-1 line-clamp-2 min-h-[3rem] group-hover:text-indigo-400 transition-colors">
              {listing.title}
            </h3>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-2">
                <span className="flex items-center"><Star className="w-3 h-3 text-yellow-500 mr-1 fill-yellow-500" /> {listing.rating || "5.0"}</span>
                <span className="flex items-center"><Download className="w-3 h-3 mr-1" /> {listing.sales || 0}</span>
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex flex-col items-start justify-between border-t border-white/5 mt-auto bg-white/[0.01]">
              <div className="flex w-full items-center justify-between mb-2 mt-3">
                <div className="flex flex-col">
                   {discountPct > 0 ? (
                     <>
                        <span className="text-xs text-muted-foreground line-through">{convert(listing.price)}</span>
                        <span className="text-lg font-bold text-emerald-400">{convert(discountedPrice)}</span>
                     </>
                   ) : (
                      <span className="text-lg font-bold">{convert(listing.price)}</span>
                   )}
                </div>
                {currentUserId && currentUserId === listing.seller_id ? (
                  <Link to={`/manage/${listing.id}`} onClick={(e) => e.stopPropagation()}>
                    <Button size="sm" variant="outline" className="h-8 rounded-full border-indigo-500/50 text-indigo-400 hover:bg-indigo-500/10">Manage</Button>
                  </Link>
                ) : (
                  <Button size="sm" variant="secondary" className="h-8 rounded-full bg-white/10 hover:bg-white/20">
                    Get details
                  </Button>
                )}
              </div>
              <div className="flex items-center text-xs text-muted-foreground gap-1">
                <User className="w-3 h-3" />
                {listing.author}
                {listing.is_verified ? <CheckCircle className="w-3 h-3 text-emerald-400" /> : null}
              </div>
          </CardFooter>
        </Card>
      </Link>
    </motion.div>
  );
}

// -------------------------------------------------------------
// Play Store Style Card for Mobile Apps
// -------------------------------------------------------------
function PlayStoreCard({ listing, i, currentUserId }: { key?: string | number, listing: Listing; i: number; currentUserId?: string }) {
  const { convert } = useCurrency();
  const discountPct = listing.discount_percentage || 0;
  const discountedPrice = listing.price - (listing.price * (discountPct / 100));

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.05 }}
    >
      <Link to={`/listing/${listing.id}`} className="block group h-full">
        <div className="flex flex-col h-full bg-white/[0.02] hover:bg-white/[0.05] p-3 rounded-2xl border border-transparent hover:border-white/10 transition-all cursor-pointer">
          <div className="relative mb-3">
             <img 
               src={listing.image_url || listing.image} 
               alt={listing.title}
               className="w-full aspect-square rounded-2xl object-cover shadow-lg group-hover:shadow-[0_0_20px_rgba(255,255,255,0.1)] transition-all"
             />
             {discountPct > 0 && listing.discount_type === "Limited Time" && (
                <div className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-lg shadow-red-500/20 z-10 animate-pulse">
                  {discountPct}% OFF
                </div>
             )}
          </div>
          <div className="flex-1">
             <h3 className="font-semibold text-sm line-clamp-1 group-hover:text-amber-400 transition-colors">{listing.title}</h3>
             <p className="text-[11px] text-muted-foreground line-clamp-1 mb-1">{listing.custom_badge || listing.type}</p>
             <div className="flex items-center text-[10px] text-yellow-500 mb-2">
                <span>★ {listing.rating || "5.0"}</span>
             </div>
          </div>
          <div className="mt-auto flex items-center justify-between">
             <div>
               {discountPct > 0 ? (
                 <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-muted-foreground line-through">{convert(listing.price)}</span>
                    <span className="text-sm font-bold text-emerald-400">{convert(discountedPrice)}</span>
                 </div>
               ) : (
                  <span className="text-sm font-bold">{convert(listing.price)}</span>
               )}
             </div>
             {currentUserId && currentUserId === listing.seller_id && (
               <Link to={`/manage/${listing.id}`} onClick={(e) => e.stopPropagation()}>
                  <Button size="sm" variant="outline" className="h-6 text-[10px] px-2 rounded-full border-indigo-500/50 text-indigo-400 hover:bg-indigo-500/10">Manage</Button>
               </Link>
             )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

// -------------------------------------------------------------
// Large Website Showcase Card
// -------------------------------------------------------------
function WebsiteCard({ listing, i, currentUserId }: { key?: string | number, listing: Listing; i: number; currentUserId?: string }) {
  const { convert } = useCurrency();
  const discountPct = listing.discount_percentage || 0;
  const discountedPrice = listing.price - (listing.price * (discountPct / 100));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.1 }}
      className="h-full"
    >
      <Link to={`/listing/${listing.id}`} className="block group h-full">
        <Card className="bg-black/20 border-white/5 hover:border-blue-500/30 transition-all duration-300 h-full overflow-hidden flex flex-col">
          {/* MacOS style window header */}
          <div className="h-8 bg-white/[0.03] border-b border-white/5 flex items-center px-4 gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
            <div className="ml-4 text-xs text-muted-foreground truncate opacity-50 flex items-center gap-2">
               <Lock className="w-3 h-3" /> omniverse.app/demo/{listing.id.slice(0, 5)}
            </div>
          </div>
          <div className="relative aspect-[16/10] overflow-hidden bg-black/50">
            <img 
               src={listing.image_url || listing.image} 
               alt={listing.title}
               className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700"
            />
            {discountPct > 0 && listing.discount_type === "Limited Time" && (
                <Badge className="absolute top-4 right-4 bg-red-500 text-white font-bold border-none shadow-lg animate-pulse">
                  {discountPct}% OFF - Limited Time
                </Badge>
             )}
             {listing.custom_badge && (
               <Badge className="absolute bottom-4 left-4 bg-indigo-600/90 backdrop-blur-md text-white font-medium border-none shadow-lg">
                  {listing.custom_badge}
               </Badge>
             )}
          </div>
          <CardContent className="p-6 flex-1 flex flex-col">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-display font-medium text-2xl group-hover:text-blue-400 transition-colors leading-tight">
                {listing.title}
              </h3>
              <div className="bg-white/5 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-3">
                {currentUserId && currentUserId === listing.seller_id && (
                  <Link to={`/manage/${listing.id}`} onClick={(e) => e.stopPropagation()}>
                     <span className="text-indigo-400 text-xs hover:underline cursor-pointer">Manage System</span>
                  </Link>
                )}
                {discountPct > 0 ? (
                   <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground line-through">{convert(listing.price)}</span>
                      <span className="text-emerald-400 leading-none">{convert(discountedPrice)}</span>
                   </div>
                ) : (
                   <span>{convert(listing.price)}</span>
                )}
              </div>
            </div>
            <p className="text-muted-foreground text-sm line-clamp-2 mt-auto">
              {listing.description}
            </p>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}
