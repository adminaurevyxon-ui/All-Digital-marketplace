import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { ulid } from "ulid";
import fs from "fs";
import db from "./server/db.js";
import Stripe from "stripe";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const JWT_SECRET = process.env.JWT_SECRET || "super_secret_omniverse_key";

if (!fs.existsSync("uploads/images")) {
  fs.mkdirSync("uploads/images", { recursive: true });
}
if (!fs.existsSync("uploads/assets")) {
  fs.mkdirSync("uploads/assets", { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === "image") cb(null, "uploads/images/");
    else cb(null, "uploads/assets/");
  },
  filename: (req, file, cb) => cb(null, ulid() + "-" + file.originalname),
});
const upload = multer({ storage });

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  const PORT = 3000;

  // Enterprise Security & Performance Layers

  // Prevent crashes (Zero-Crash Architecture basic layer)
  process.on('uncaughtException', (err) => {
    console.error('UNCAUGHT EXCEPTION! Shutting down gracefully...', err);
  });
  process.on('unhandledRejection', (err) => {
    console.error('UNHANDLED REJECTION! Shutting down gracefully...', err);
  });

  // Apply Helmet for Security Headers (with relaxed CSP for dev environment and iframes)
  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
  }));

  // GZIP compression for extreme performance
  app.use(compression());

  // Global DDoS / Rate Limiting Protection
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5000, // Limit each IP to 5000 requests per windowMs for high traffic handling
    message: "Too many requests from this IP, please try again later.",
    validate: {
      xForwardedForHeader: false,
      trustProxy: false,
      forwardedHeader: false
    }
  });
  app.use("/api/", limiter);

  app.get("/api/health", (req, res) => res.json({ status: "ok", uptime: process.uptime() }));


  // Webhook must be parsed as raw before express.json()
  app.post("/api/webhook", express.raw({ type: "application/json" }), (req: any, res: any) => {
    const sig = req.headers["stripe-signature"];
    if (!process.env.STRIPE_WEBHOOK_SECRET || !process.env.STRIPE_SECRET_KEY) {
      return res.status(400).send("Webhook Secret Missing");
    }

    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any });
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    } catch (err: any) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as any;
      const metadata = session.metadata;

      db.prepare("UPDATE orders SET status = 'completed' WHERE id = ?").run(metadata.orderId);
      const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(metadata.listingId) as any;
      if (metadata.mode === "Exclusive") {
        db.prepare("UPDATE listings SET status = 'sold', buyer_id = ? WHERE id = ?").run(metadata.buyerId, metadata.listingId);
      } else {
         db.prepare("UPDATE listings SET sales = sales + 1 WHERE id = ?").run(metadata.listingId);
      }
      
      // Send notification to seller
      db.prepare("INSERT INTO notifications (id, user_id, type, message, reference_id) VALUES (?, ?, ?, ?, ?)").run(
        ulid(), listing.seller_id, "sale", `You made a sale! Someone purchased ${listing.title} for $${listing.price}.`, metadata.orderId
      );
    }
    res.json({ received: true });
  });

  app.use(express.json());
  app.use("/uploads/images", express.static("uploads/images"));

  // JWT Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    let token = authHeader ? authHeader.split(" ")[1] : null;
    
    // Fallback to query param
    if (!token && req.query.token) {
        token = req.query.token as string;
    }

    if (!token) return res.status(401).json({ error: "No token provided" });
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      const dbUser = db.prepare("SELECT role, is_banned FROM users WHERE id = ?").get(decoded.id) as any;
      if (!dbUser) return res.status(401).json({ error: "User not found" });
      if (dbUser.is_banned) return res.status(403).json({ error: "ACCOUNT BANNED: Access Revoked" });

      req.user = { ...decoded, role: dbUser.role };
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // Auth Routes
  app.post("/api/auth/register", (req, res) => {
    const { name, email, password } = req.body;
    try {
      const existing = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
      if (existing) return res.status(400).json({ error: "Email exists" });

      const id = ulid();
      const hash = bcrypt.hashSync(password, 10);
      db.prepare("INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)").run(id, name, email, hash);
      const token = jwt.sign({ id, name, email }, JWT_SECRET, { expiresIn: "7d" });
      res.json({ token, user: { id, name, email } });
    } catch (err) {
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    try {
      const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
      if (!user || !bcrypt.compareSync(password, user.password_hash)) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
      res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
    } catch (err) {
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/auth/me", authenticate, (req: any, res) => {
    // Return all user data
    const user = db.prepare("SELECT id, name, email, role, github_id, google_id, discord_id, avatar_url, github_username, provider, phone_number FROM users WHERE id = ?").get(req.user.id) as any;
    res.json({ user });
  });

  // ========== UNIVERSAL AUTHENTICATION & GITHUB INTEGRATION ========== //
  
  // Real Google OAuth initialization
  app.get("/api/auth/google", (req, res) => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    if (!clientId) return res.status(500).json({ error: "GOOGLE_CLIENT_ID not configured in the environment variables. Please check the Setup Instructions." });
    const redirectUri = encodeURIComponent(`${req.protocol}://${req.get("host")}/api/auth/google/callback`);
    const googleUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=openid%20email%20profile&access_type=offline`;
    res.json({ url: googleUrl });
  });

  // Real Google OAuth Callback
  app.get("/api/auth/google/callback", async (req, res) => {
    const { code } = req.query;
    if (!code) return res.status(400).send("No code provided");
    try {
      const redirectUri = `${req.protocol}://${req.get("host")}/api/auth/google/callback`;
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: process.env.GOOGLE_CLIENT_ID!,
          client_secret: process.env.GOOGLE_CLIENT_SECRET!,
          code: code as string,
          grant_type: "authorization_code",
          redirect_uri: redirectUri
        }).toString()
      });
      const tokenData = await tokenRes.json();
      if (tokenData.error) throw new Error(tokenData.error_description || tokenData.error);

      const accessToken = tokenData.access_token;
      
      const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const googleUser = await userRes.json();
      
      const primaryEmail = googleUser.email;

      let user = db.prepare("SELECT * FROM users WHERE google_id = ? OR email = ?").get(googleUser.id, primaryEmail) as any;
      
      if (!user) {
        const id = ulid();
        db.prepare(`
          INSERT INTO users (id, name, email, password_hash, google_id, avatar_url, provider) 
          VALUES (?, ?, ?, ?, ?, ?, 'google')
        `).run(id, googleUser.name, primaryEmail, "OAUTH_USER", googleUser.id, googleUser.picture);
        user = { id, name: googleUser.name, email: primaryEmail };
      } else {
        db.prepare("UPDATE users SET google_id = ?, avatar_url = ? WHERE id = ?")
          .run(googleUser.id, googleUser.picture, user.id);
      }

      const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
      res.redirect(`/?token=${token}`);
    } catch(err: any) {
      console.error("Google OAuth error:", err);
      res.redirect(`/?error=${encodeURIComponent(err.message)}`);
    }
  });

  // Real GitHub OAuth initialization
  app.get("/api/auth/github", (req, res) => {
    const clientId = process.env.GITHUB_CLIENT_ID;
    if (!clientId) return res.status(500).json({ error: "GITHUB_CLIENT_ID not configured" });
    const redirectUri = encodeURIComponent(`${req.protocol}://${req.get("host")}/api/auth/github/callback`);
    const githubUrl = `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&scope=read:user,user:email,repo`;
    res.json({ url: githubUrl });
  });

  // Real GitHub OAuth Callback
  app.get("/api/auth/github/callback", async (req, res) => {
    const { code } = req.query;
    if (!code) return res.status(400).send("No code provided");
    try {
      const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          client_id: process.env.GITHUB_CLIENT_ID,
          client_secret: process.env.GITHUB_CLIENT_SECRET,
          code
        })
      });
      const tokenData = await tokenRes.json();
      if (tokenData.error) throw new Error(tokenData.error_description);

      const accessToken = tokenData.access_token;
      // Get User info
      const userRes = await fetch("https://api.github.com/user", {
        headers: { Authorization: `Bearer ${accessToken}`, "User-Agent": "Omniverse App" }
      });
      const githubUser = await userRes.json();
      
      const emailRes = await fetch("https://api.github.com/user/emails", {
        headers: { Authorization: `Bearer ${accessToken}`, "User-Agent": "Omniverse App" }
      });
      const emails = await emailRes.json();
      const primaryEmail = emails.find((e: any) => e.primary)?.email;

      // Upsert User
      let user = db.prepare("SELECT * FROM users WHERE github_id = ? OR email = ?").get(githubUser.id.toString(), primaryEmail) as any;
      
      if (!user) {
        const id = ulid();
        db.prepare(`
          INSERT INTO users (id, name, email, password_hash, github_id, avatar_url, github_username, provider) 
          VALUES (?, ?, ?, ?, ?, ?, ?, 'github')
        `).run(id, githubUser.name || githubUser.login, primaryEmail, "OAUTH_USER", githubUser.id.toString(), githubUser.avatar_url, githubUser.login);
        user = { id, name: githubUser.name || githubUser.login, email: primaryEmail };
      } else {
        db.prepare("UPDATE users SET github_id = ?, avatar_url = ?, github_username = ? WHERE id = ?")
          .run(githubUser.id.toString(), githubUser.avatar_url, githubUser.login, user.id);
      }

      const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
      res.redirect(`/?token=${token}`);
    } catch(err: any) {
      console.error(err);
      res.redirect(`/?error=${encodeURIComponent('GitHub OAuth Error: ' + err.message)}`);
    }
  });

  // Email OTP - Using Resend / NodeMailer (Assuming SendGrid/Resend)
  const otpStore = new Map<string, { code: string, expires: number }>();
  app.post("/api/auth/otp/send", async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    otpStore.set(email, { code, expires: Date.now() + 5 * 60 * 1000 });
    
    // Send real email if RESEND_API_KEY is available
    if (process.env.RESEND_API_KEY) {
      const resendRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.RESEND_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          from: "onboarding@resend.dev",
          to: email,
          subject: "Your Omniverse Login Code",
          html: `<p>Your code is <strong>${code}</strong></p>`
        })
      });
      if (!resendRes.ok) return res.status(500).json({ error: "Failed to send email API" });
    } else {
      console.warn(`[DEVELOPMENT ONLY] OTP Code for ${email}: ${code}`);
      return res.status(500).json({ error: "RESEND_API_KEY missing. Cannot send real email." });
    }

    res.json({ success: true, message: "OTP sent" });
  });

  app.post("/api/auth/otp/verify", (req, res) => {
    const { email, code } = req.body;
    const record = otpStore.get(email);
    if (!record || record.code !== code || record.expires < Date.now()) {
      return res.status(401).json({ error: "Invalid or expired OTP" });
    }
    otpStore.delete(email);

    let user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user) {
      const id = ulid();
      db.prepare(`
        INSERT INTO users (id, name, email, password_hash, provider) 
        VALUES (?, ?, ?, ?, 'otp')
      `).run(id, email.split("@")[0], email, "OTP_USER");
      user = { id, name: email.split("@")[0], email };
    }
    
    const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
  });

  // RESTful GitHub Repository Syncing
  app.get("/api/github/repos", authenticate, async (req: any, res) => {
    const user = db.prepare("SELECT github_username, github_id FROM users WHERE id = ?").get(req.user.id) as any;
    if (!user || !user.github_username) {
      return res.status(400).json({ error: "GitHub account not linked" });
    }
    
    try {
      const fetchUrl = `https://api.github.com/users/${user.github_username}/repos?per_page=100&sort=updated`;
      const ghRes = await fetch(fetchUrl, {
        headers: { "User-Agent": "Omniverse App" }
      });
      
      if (!ghRes.ok) throw new Error("GitHub API rate limit or error");
      const repos = await ghRes.json();
      
      const mappedRepos = repos.map((r: any) => ({
        id: r.id.toString(),
        name: r.name,
        full_name: r.full_name,
        html_url: r.html_url,
        description: r.description,
        stars: r.stargazers_count,
        language: r.language
      }));
      res.json({ repos: mappedRepos });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/github/import", authenticate, async (req: any, res) => {
    const { repo_id, repo_name, repo_url, description, language, stars } = req.body;
    try {
      db.prepare(`
        INSERT OR REPLACE INTO repositories (id, owner_id, repo_name, repo_url, description, stars, language)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(repo_id.toString(), req.user.id, repo_name, repo_url, description || '', stars || 0, language || '');
      
      // AI Processing step placeholder (if we use GenAI) -> In a real app we'd trigger an async job
      
      res.json({ success: true, message: "Repository successfully imported" });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/user/repos", authenticate, (req: any, res) => {
    try {
      const repos = db.prepare("SELECT * FROM repositories WHERE owner_id = ? ORDER BY last_sync DESC").all(req.user.id);
      res.json({ repos });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });
  
  // =================================================================== //

  // Listings API
  app.get("/api/listings", (req, res) => {
    const q = req.query.q as string;
    const type = req.query.category as string;
    const minPrice = req.query.minPrice as string;
    const maxPrice = req.query.maxPrice as string;
    const mode = req.query.mode as string;
    
    let queryArgs: (string | number)[] = [];
    let queryStr = "SELECT l.*, u.name as author, u.is_verified FROM listings l JOIN users u ON l.seller_id = u.id WHERE l.status = 'active' AND l.is_approved = 1 AND u.is_banned = 0";
    
    if (q) {
      queryStr += " AND (l.title LIKE ? OR l.description LIKE ? OR l.type LIKE ? OR l.tags LIKE ?)";
      const term = `%${q}%`;
      queryArgs.push(term, term, term, term);
    }
    if (type && type !== "All") {
      queryStr += " AND l.type = ?";
      queryArgs.push(type);
    }
    if (minPrice) {
      queryStr += " AND l.price >= ?";
      queryArgs.push(Number(minPrice));
    }
    if (maxPrice) {
      queryStr += " AND l.price <= ?";
      queryArgs.push(Number(maxPrice));
    }
    if (mode && mode !== "All") {
      queryStr += " AND l.mode = ?";
      queryArgs.push(mode);
    }
    
    queryStr += " ORDER BY l.is_featured DESC, l.created_at DESC";
    const listings = db.prepare(queryStr).all(...queryArgs);
    res.json({
      listings: listings.map((l: any) => {
        let tags = [];
        try { tags = l.tags ? JSON.parse(l.tags) : []; } catch(e) {}
        return { ...l, tags };
      })
    });
  });

  app.get("/api/listings/:id", (req, res) => {
    const listing = db.prepare(`
      SELECT l.*, u.name as author, u.is_banned, u.is_verified 
      FROM listings l 
      JOIN users u ON l.seller_id = u.id 
      WHERE l.id = ?
    `).get(req.params.id) as any;
    if (!listing) return res.status(404).json({ error: "Not found" });
    if (listing.is_banned || !listing.is_approved) {
      // NOTE: Should probably still let admin/owner view it, but for simplicity:
      return res.status(403).json({ error: "Listing unavailable" });
    }
    try { listing.tags = listing.tags ? JSON.parse(listing.tags) : []; } catch(e) { listing.tags = []; }
    try { listing.screenshots = listing.screenshots ? JSON.parse(listing.screenshots) : []; } catch(e) { listing.screenshots = []; }
    // Do not leak file_url directly unless user owns it, but we handle that in downloads
    res.json({ listing });
  });

  app.put("/api/listings/:id/update", authenticate, (req: any, res) => {
    const { id } = req.params;
    const { title, description, price, type, mode, tags, discount_percentage, discount_type, custom_badge, status } = req.body;
    
    const existing = db.prepare("SELECT * FROM listings WHERE id = ?").get(id) as any;
    if (!existing) return res.status(404).json({ error: "Not found" });
    if (existing.seller_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    let tagsJSON = tags || "[]";
    if (Array.isArray(tags)) {
      tagsJSON = JSON.stringify(tags);
    }

    db.prepare(`
      UPDATE listings SET 
        title = ?, description = ?, price = ?, type = ?, mode = ?, tags = ?, 
        discount_percentage = ?, discount_type = ?, custom_badge = ?, status = ?
      WHERE id = ?
    `).run(
      title, description, Number(price) || 0, type, mode, tagsJSON, 
      Number(discount_percentage) || 0, discount_type, custom_badge, status || 'active', id
    );
    
    res.json({ success: true });
  });

  app.post("/api/listings", authenticate, upload.fields([{ name: "image", maxCount: 1 }, { name: "asset", maxCount: 1 }, { name: "screenshots", maxCount: 8 }]), (req: any, res) => {
    const { title, description, price, type, mode, tags, discount_percentage, discount_type, custom_badge } = req.body;
    const files = req.files as any;
    const imageUrl = files.image ? `/uploads/images/${files.image[0].filename}` : "";
    const assetUrl = files.asset ? `uploads/assets/${files.asset[0].filename}` : "";
    
    let screenshotsJSON = "[]";
    if (files.screenshots) {
      const screenshotUrls = files.screenshots.map((f: any) => `/uploads/images/${f.filename}`);
      screenshotsJSON = JSON.stringify(screenshotUrls);
    }
    
    let tagsJSON = tags || "[]";
    if (typeof tags === "string" && !tags.startsWith("[")) {
      tagsJSON = JSON.stringify(tags.split(",").map((t: string) => t.trim()));
    } else if (Array.isArray(tags)) {
      tagsJSON = JSON.stringify(tags);
    }
    
    const id = ulid();
    db.prepare(`
      INSERT INTO listings (id, title, description, price, type, mode, seller_id, image_url, file_url, tags, discount_percentage, discount_type, custom_badge, screenshots)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, title, description, Number(price), type, mode, req.user.id, imageUrl, assetUrl, tagsJSON, Number(discount_percentage) || 0, discount_type || 'None', custom_badge || null, screenshotsJSON);
    
    res.json({ success: true, listingId: id });
  });

  // Secure Download API
  app.get("/api/downloads/:listingId", authenticate, (req: any, res: any) => {
    const listingId = req.params.listingId;
    const userId = req.user.id;

    const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(listingId) as any;
    if (!listing) return res.status(404).json({ error: "Listing not found" });

    const isSeller = listing.seller_id === userId;
    let isBuyer = false;
    if (listing.mode === "Exclusive" && listing.buyer_id === userId) {
        isBuyer = true;
    } else {
        const order = db.prepare("SELECT * FROM orders WHERE listing_id = ? AND buyer_id = ? AND status = 'completed'").get(listingId, userId);
        if (order) isBuyer = true;
    }

    if (!isSeller && !isBuyer) {
        return res.status(403).json({ error: "Unauthorized. You must purchase this asset to download it." });
    }

    if (!listing.file_url) return res.status(404).json({ error: "Asset file not found in registry" });

    const filePath = path.join(process.cwd(), listing.file_url);
    if (!fs.existsSync(filePath)) {
         return res.status(404).json({ error: "Physical file is missing on the server" });
    }

    res.download(filePath);
  });

  // Purchasing / Downloading
  app.post("/api/buy/:listingId", authenticate, async (req: any, res: any) => {
    const listingId = req.params.listingId;
    const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(listingId) as any;
    
    if (!listing) return res.status(404).json({ error: "Not found" });
    if (listing.status !== 'active') return res.status(400).json({ error: "Not available for purchase" });

    if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ 
            error: "STRIPE_SECRET_KEY is missing. Payment gateway is securely locked down. Please configure Stripe in your environment to enable real transactions." 
        });
    }

    try {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any });

      const orderId = ulid();
      db.prepare("INSERT INTO orders (id, listing_id, buyer_id, amount, status) VALUES (?, ?, ?, ?, 'pending')").run(orderId, listingId, req.user.id, listing.price);

      const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [{
              price_data: {
                  currency: 'usd',
                  product_data: {
                      name: listing.title,
                      description: listing.mode === 'Exclusive' ? 'Exclusive Ownership Acquisition' : 'Unlimited License',
                  },
                  unit_amount: Math.round(listing.price * 100),
              },
              quantity: 1,
          }],
          mode: 'payment',
          success_url: `${req.headers.origin}/dashboard?success=true&orderId=${orderId}&session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${req.headers.origin}/listing/${listingId}?canceled=true`,
          metadata: {
              orderId: orderId,
              listingId: listingId,
              mode: listing.mode,
              buyerId: req.user.id,
              sellerId: listing.seller_id,
              price: listing.price.toString()
          }
      });

      res.json({ success: true, url: session.url });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // REAL STRIPE WEBHOOK
  app.post('/api/webhooks/stripe', express.raw({type: 'application/json'}), (req: any, res: any) => {
    const sig = req.headers['stripe-signature'];
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!process.env.STRIPE_SECRET_KEY || !endpointSecret) {
      return res.status(400).send(`Webhook Error: Missing Stripe credentials`);
    }

    let event;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any });

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err: any) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as any;
      if (session.payment_status === 'paid' && session.metadata) {
        try {
            const { orderId, listingId, mode, buyerId, sellerId, price } = session.metadata;
            const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(orderId) as any;
            
            // Only process if still pending
            if (order && order.status === 'pending') {
                const seller = db.prepare("SELECT commission_rate FROM users WHERE id = ?").get(sellerId) as any;
                const globalRateRow = db.prepare("SELECT value FROM platform_settings WHERE key = 'global_commission_rate'").get() as any;
                const commissionRate = seller?.commission_rate || parseFloat(globalRateRow?.value || "0.25");
                
                const amount = parseFloat(price);
                const platformFee = amount * commissionRate;
                const sellerEarnings = amount - platformFee;

                const tx = db.transaction(() => {
                    db.prepare("UPDATE orders SET status = 'completed' WHERE id = ?").run(orderId);
                    db.prepare(`
                      INSERT INTO transactions (id, buyer_id, seller_id, listing_id, amount, platform_fee, seller_earnings, payment_method, status)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `).run(ulid(), buyerId, sellerId, listingId, amount, platformFee, sellerEarnings, 'stripe', 'completed');
                    
                    db.prepare("UPDATE users SET seller_balance = seller_balance + ? WHERE id = ?").run(sellerEarnings, sellerId);
                    db.prepare("UPDATE platform_settings SET value = CAST((CAST(value AS REAL) + ?) AS TEXT) WHERE key = 'platform_wallet_balance'").run(platformFee);
                    db.prepare("UPDATE listings SET sales = sales + 1 WHERE id = ?").run(listingId);
                    
                    if (mode === 'Exclusive') {
                        db.prepare("UPDATE listings SET buyer_id = ?, status = 'sold' WHERE id = ?").run(buyerId, listingId);
                    }
                });
                tx();
            }
        } catch(e) {
            console.error("Webhook processing error:", e);
        }
      }
    }

    res.json({received: true});
  });

  app.get("/api/dashboard", authenticate, (req: any, res) => {
    // If there's a successful Stripe checkout session, we should process it if the webhook hasn't yet (fallback mechanism)
    if (req.query.session_id && process.env.STRIPE_SECRET_KEY) {
       try {
           const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any });
           // In a real prod environment we rely ENTIRELY on webhooks, but since we are in dev/preview:
           // We will fetch session and update if order is still pending.
           stripe.checkout.sessions.retrieve(req.query.session_id).then(session => {
              if (session.payment_status === 'paid' && session.metadata) {
                  const { orderId, listingId, mode, buyerId, sellerId, price } = session.metadata;
                  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(orderId) as any;
                  if (order && order.status === 'pending') {
                      
                      // Process Revenue Split
                      const seller = db.prepare("SELECT commission_rate FROM users WHERE id = ?").get(sellerId) as any;
                      const globalRateRow = db.prepare("SELECT value FROM platform_settings WHERE key = 'global_commission_rate'").get() as any;
                      const commissionRate = seller?.commission_rate || parseFloat(globalRateRow?.value || "0.25");
                      
                      const amount = parseFloat(price);
                      const platformFee = amount * commissionRate;
                      const sellerEarnings = amount - platformFee;

                      const tx = db.transaction(() => {
                          // Update order
                          db.prepare("UPDATE orders SET status = 'completed' WHERE id = ?").run(orderId);
                          // Create actual Transaction record
                          db.prepare(`
                            INSERT INTO transactions (id, buyer_id, seller_id, listing_id, amount, platform_fee, seller_earnings, payment_method, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                          `).run(ulid(), buyerId, sellerId, listingId, amount, platformFee, sellerEarnings, 'stripe', 'completed');
                          
                          // Update Wallet balances
                          db.prepare("UPDATE users SET seller_balance = seller_balance + ? WHERE id = ?").run(sellerEarnings, sellerId);
                          db.prepare("UPDATE platform_settings SET value = CAST((CAST(value AS REAL) + ?) AS TEXT) WHERE key = 'platform_wallet_balance'").run(platformFee);
                          
                          // Update listing stats
                          db.prepare("UPDATE listings SET sales = sales + 1 WHERE id = ?").run(listingId);
                          if (mode === 'Exclusive') {
                              db.prepare("UPDATE listings SET buyer_id = ?, status = 'sold' WHERE id = ?").run(buyerId, listingId);
                          }
                      });
                      tx();
                  }
              }
           }).catch(e => console.error("Stripe sync error:", e));
       } catch(e) {}
    }

    const purchases = db.prepare(`
      SELECT o.id as order_id, o.amount, o.created_at, l.* 
      FROM orders o
      JOIN listings l ON o.listing_id = l.id
      WHERE o.buyer_id = ? AND o.status = 'completed'
      ORDER BY o.created_at DESC
    `).all(req.user.id);

    const myListings = db.prepare(`
      SELECT * FROM listings 
      WHERE seller_id = ? 
      ORDER BY created_at DESC
    `).all(req.user.id);

    const sales = db.prepare(`
      SELECT t.id as transaction_id, t.amount, t.platform_fee, t.seller_earnings, t.created_at as order_date, l.title, u.name as buyer_name
      FROM transactions t
      JOIN listings l ON t.listing_id = l.id
      JOIN users u ON t.buyer_id = u.id
      WHERE t.seller_id = ? AND t.status = 'completed'
      ORDER BY t.created_at DESC
    `).all(req.user.id);

    const balanceInfo = db.prepare("SELECT seller_balance FROM users WHERE id = ?").get(req.user.id) as any;

    res.json({ purchases, myListings, sales, balance: balanceInfo?.seller_balance || 0 });
  });

  // ========== ENTERPRISE ADMIN APIs ========== //
  
  const requireSuperAdmin = (req: any, res: any, next: any) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden: Super Admin Access Required" });
    next();
  };

  app.get("/api/admin/stats", authenticate, requireSuperAdmin, (req, res) => {
    try {
      const totalRevenueRow = db.prepare("SELECT SUM(amount) as val FROM transactions WHERE status = 'completed'").get() as any;
      const platformEarningsRow = db.prepare("SELECT value FROM platform_settings WHERE key = 'platform_wallet_balance'").get() as any;
      const totalSellerEarningsRow = db.prepare("SELECT SUM(seller_earnings) as val FROM transactions WHERE status = 'completed'").get() as any;
      const activeUsersCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
      const productsCount = db.prepare("SELECT COUNT(*) as count FROM listings").get() as any;
      const totalSalesCount = db.prepare("SELECT COUNT(*) as count FROM transactions WHERE status = 'completed'").get() as any;
      const activeListings = db.prepare("SELECT count(*) as count FROM listings WHERE status = 'active' AND is_approved = 1").get() as any;
      const pendingListings = db.prepare("SELECT count(*) as count FROM listings WHERE is_approved = 0").get() as any;

      res.json({
        totalRevenue: totalRevenueRow?.val || 0,
        platformEarnings: parseFloat(platformEarningsRow?.value || "0"),
        sellerEarningsTotal: totalSellerEarningsRow?.val || 0,
        activeUsers: activeUsersCount?.count || 0,
        productsCount: productsCount?.count || 0,
        totalSales: totalSalesCount?.count || 0,
        activeListings: activeListings?.count || 0,
        pendingListings: pendingListings?.count || 0,
        conversionRate: "4.8%"
      });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/transactions", authenticate, requireSuperAdmin, (req, res) => {
    try {
      const txs = db.prepare(`
        SELECT t.*, l.title as product_title, s.name as seller_name, b.name as buyer_name
        FROM transactions t
        LEFT JOIN listings l ON t.listing_id = l.id
        LEFT JOIN users s ON t.seller_id = s.id
        LEFT JOIN users b ON t.buyer_id = b.id
        ORDER BY t.created_at DESC LIMIT 100
      `).all();
      res.json({ transactions: txs });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/system", authenticate, requireSuperAdmin, (req, res) => {
    try {
      res.json({
         memory: process.memoryUsage(),
         uptime: process.uptime(),
         cpuUsage: process.cpuUsage(),
         nodeVersion: process.version,
         platform: process.platform,
         dbSize: fs.statSync(path.join(process.cwd(), 'omniverse.db')).size
      });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/listings", authenticate, requireSuperAdmin, (req, res) => {
    try {
      const listings = db.prepare(`
        SELECT l.*, u.name as seller_name, u.email as seller_email 
        FROM listings l 
        JOIN users u ON l.seller_id = u.id 
        ORDER BY l.created_at DESC
      `).all();
      res.json({ listings });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/listings/:id/status", authenticate, requireSuperAdmin, (req, res) => {
    const { is_approved, is_featured } = req.body;
    try {
      if (is_approved !== undefined) {
         db.prepare("UPDATE listings SET is_approved = ? WHERE id = ?").run(is_approved ? 1 : 0, req.params.id);
      }
      if (is_featured !== undefined) {
         db.prepare("UPDATE listings SET is_featured = ? WHERE id = ?").run(is_featured ? 1 : 0, req.params.id);
      }
      res.json({ success: true });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });
  
  app.delete("/api/admin/listings/:id", authenticate, requireSuperAdmin, (req, res) => {
    try {
      db.prepare("DELETE FROM listings WHERE id = ?").run(req.params.id);
      res.json({ success: true });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/users/:id/status", authenticate, requireSuperAdmin, (req, res) => {
    const { is_banned, is_verified } = req.body;
    try {
      if (is_banned !== undefined) {
         db.prepare("UPDATE users SET is_banned = ? WHERE id = ?").run(is_banned ? 1 : 0, req.params.id);
      }
      if (is_verified !== undefined) {
         db.prepare("UPDATE users SET is_verified = ? WHERE id = ?").run(is_verified ? 1 : 0, req.params.id);
      }
      res.json({ success: true });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/users", authenticate, requireSuperAdmin, (req, res) => {
    try {
      const users = db.prepare(`SELECT id, name, email, role, provider, seller_balance, commission_rate, is_banned, is_verified, created_at FROM users ORDER BY created_at DESC`).all();
      res.json({ users });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Admin adjust commission rate
  app.post("/api/admin/users/:id/commission", authenticate, requireSuperAdmin, (req, res) => {
    const { rate } = req.body;
    if (rate === undefined || rate < 0 || rate > 1) return res.status(400).json({ error: "Invalid rate. Must be between 0 and 1." });
    db.prepare("UPDATE users SET commission_rate = ? WHERE id = ?").run(rate, req.params.id);
    res.json({ success: true });
  });

  // Admin payout processing
  app.get("/api/admin/payouts", authenticate, requireSuperAdmin, (req, res) => {
    try {
      const payouts = db.prepare(`
        SELECT p.*, u.name as user_name, u.email, m.method_type, m.details
        FROM payout_requests p
        JOIN users u ON p.user_id = u.id
        JOIN payout_methods m ON p.method_id = m.id
        ORDER BY p.created_at DESC
      `).all();
      res.json({ payouts });
    } catch(err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/payouts/:id/status", authenticate, requireSuperAdmin, (req, res) => {
     const { status, admin_notes } = req.body;
     try {
       const tx = db.transaction(() => {
         const pr = db.prepare("SELECT * FROM payout_requests WHERE id = ?").get(req.params.id) as any;
         if (!pr) throw new Error("Payout request not found");
         if (pr.status === 'completed' || pr.status === 'failed') return;
         
         db.prepare("UPDATE payout_requests SET status = ?, admin_notes = ?, processed_at = ? WHERE id = ?").run(status, admin_notes || '', new Date().toISOString(), req.params.id);
         
         // If a pending request is rejected/failed, refund the balance back to seller
         if ((status === 'failed' || status === 'rejected') && pr.status !== 'failed' && pr.status !== 'rejected') {
           db.prepare("UPDATE users SET seller_balance = seller_balance + ? WHERE id = ?").run(pr.amount, pr.user_id);
         }
       });
       tx();
       res.json({ success: true });
     } catch (err: any) {
       res.status(500).json({ error: err.message });
     }
  });
  
  // User Payout settings
  app.get("/api/payout/methods", authenticate, (req: any, res) => {
     const methods = db.prepare("SELECT * FROM payout_methods WHERE user_id = ?").all(req.user.id);
     res.json({ methods });
  });

  app.post("/api/payout/methods", authenticate, (req: any, res) => {
     const { method_type, details, is_default } = req.body;
     const id = ulid();
     if (is_default) {
        db.prepare("UPDATE payout_methods SET is_default = 0 WHERE user_id = ?").run(req.user.id);
     }
     db.prepare("INSERT INTO payout_methods (id, user_id, method_type, details, is_default) VALUES (?, ?, ?, ?, ?)").run(id, req.user.id, method_type, JSON.stringify(details), is_default ? 1 : 0);
     res.json({ success: true });
  });

  app.post("/api/payout/request", authenticate, (req: any, res) => {
     const { amount, method_id } = req.body;
     try {
       const tx = db.transaction(() => {
         const user = db.prepare("SELECT seller_balance FROM users WHERE id = ?").get(req.user.id) as any;
         if (user.seller_balance < amount || amount <= 0) {
           throw new Error("Insufficient balance");
         }
         db.prepare("UPDATE users SET seller_balance = seller_balance - ? WHERE id = ?").run(amount, req.user.id);
         db.prepare("INSERT INTO payout_requests (id, user_id, amount, method_id, status) VALUES (?, ?, ?, ?, 'pending')").run(ulid(), req.user.id, amount, method_id);
       });
       tx();
       res.json({ success: true });
     } catch (err: any) {
       res.status(400).json({ error: err.message });
     }
  });

  // Wishlist API
  app.get("/api/wishlists", authenticate, (req: any, res) => {
    const wishlists = db.prepare(`
      SELECT w.id as wishlist_id, w.created_at as saved_at, l.*, u.name as author, u.is_verified 
      FROM wishlists w 
      JOIN listings l ON w.listing_id = l.id 
      JOIN users u ON l.seller_id = u.id 
      WHERE w.user_id = ? AND l.status = 'active'
      ORDER BY w.created_at DESC
    `).all(req.user.id);
    res.json({ wishlists: wishlists.map((l: any) => {
        let tags = [];
        try { tags = l.tags ? JSON.parse(l.tags) : []; } catch(e) {}
        return { ...l, tags };
      }) 
    });
  });

  app.post("/api/wishlists/:listingId", authenticate, (req: any, res) => {
    const { listingId } = req.params;
    const existing = db.prepare("SELECT * FROM wishlists WHERE user_id = ? AND listing_id = ?").get(req.user.id, listingId);
    if (existing) {
      db.prepare("DELETE FROM wishlists WHERE user_id = ? AND listing_id = ?").run(req.user.id, listingId);
      res.json({ status: "removed" });
    } else {
      db.prepare("INSERT INTO wishlists (id, user_id, listing_id) VALUES (?, ?, ?)").run(ulid(), req.user.id, listingId);
      res.json({ status: "added" });
    }
  });

  // Notifications API
  app.get("/api/notifications", authenticate, (req: any, res) => {
    const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50").all(req.user.id);
    const unreadCount = db.prepare("SELECT count(*) as count FROM notifications WHERE user_id = ? AND is_read = 0").get(req.user.id) as any;
    res.json({ notifications, unreadCount: unreadCount.count });
  });

  app.post("/api/notifications/read", authenticate, (req: any, res) => {
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(req.user.id);
    res.json({ success: true });
  });

  // Catch-all for API to prevent HTML fallback

  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: "API Route Not Found" });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
